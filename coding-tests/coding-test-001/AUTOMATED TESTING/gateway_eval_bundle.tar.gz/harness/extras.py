#!/usr/bin/env python3
from harness import *
import harness as hh
from harness2 import *
import random, math


def read_response(f):
    line = f.readline()
    if not line:
        return None
    status = int(line.split()[1])
    hdrs = {}
    while True:
        l = f.readline()
        if l in (b"\r\n", b"\n", b""):
            break
        k, v = l.decode("latin1").split(":", 1)
        hdrs[k.strip().lower()] = v.strip()
    body = b""
    if "content-length" in hdrs:
        body = f.read(int(hdrs["content-length"]))
    elif hdrs.get("transfer-encoding", "").lower() == "chunked":
        while True:
            sz = int(f.readline().split(b";")[0], 16)
            if sz == 0:
                f.readline()
                break
            body += f.read(sz)
            f.readline()
    return status, hdrs


def t_memory(sub):
    fx_reset()
    urllib.request.urlopen(FIX + "/ctl/record?on=0").read()
    out = {}
    for label, trig in (("drip_content_length_1MiB", "drip"), ("drip_chunked_1MiB", "dripchunk")):
        g = GW(sub, 0, tag="mem" + trig)
        base = g.rss_hwm_kb()
        res = tool("conc", f"127.0.0.1:{g.port}", f"/v1/files/{trig}", 600, timeout=120)
        time.sleep(0.5)
        out[label] = {"statuses": res["statuses"], "elapsed": round(res["elapsed"], 2), "bytes_delivered_MiB": round(res["bytes"] / 1048576), "gateway_rss_hwm_MiB": round((g.rss_hwm_kb() or 0) / 1024, 1),
                      "baseline_rss_MiB": round((base or 0) / 1024, 1), "alive": g.alive()}
        g.stop()
    urllib.request.urlopen(FIX + "/ctl/record?on=1").read()
    peak = max(v["gateway_rss_hwm_MiB"] for v in out.values())
    record("M1_512_concurrent_1MiB_responses_peak_rss", None, {**out, "peak_rss_MiB": peak, "within_512MiB_container_cap": peak < 480}, "reference container cap 512 MiB (load-test RSS target 256 MiB)", cat="mem")


def t_benign_mix(sub):
    fx_reset()
    g = GW(sub, 0, tag="mix")
    rng = random.Random(7)
    s = socket.create_connection(("127.0.0.1", g.port), timeout=10)
    f = s.makefile("rb")
    bad = []
    N = 400
    for i in range(N):
        ident = uid("mx")
        kind = rng.choice(["search", "file", "post", "post_chunked", "post_ws", "get_cl0", "many_headers", "post_crlfcrlf_in_body", "post_unread401"])
        extra = "".join(f"X-Pad{j}: v{j}\r\n" for j in range(30)) if kind == "many_headers" else ""
        if kind in ("search", "many_headers"):
            msg = f"GET /v1/search?q=a{i} HTTP/1.1\r\nHost: x\r\nX-Verified-Client-ID: {ident}\r\n{extra}\r\n".encode()
        elif kind == "file":
            msg = f"GET /v1/files/f{i} HTTP/1.1\r\nHost: x\r\nX-Verified-Client-ID: {ident}\r\n\r\n".encode()
        elif kind == "get_cl0":
            msg = f"GET /v1/search?q=b{i} HTTP/1.1\r\nHost: x\r\nX-Verified-Client-ID: {ident}\r\nContent-Length: 0\r\n\r\n".encode()
        elif kind == "post":
            b = f'{{"host":"h{i}.example.com"}}'.encode()
            msg = f"POST /v1/tools/resolve HTTP/1.1\r\nHost: x\r\nX-Verified-Client-ID: {ident}\r\nContent-Type: application/json\r\nContent-Length: {len(b)}\r\n\r\n".encode() + b
        elif kind == "post_ws":
            b = b'{"host":"w.example.com"}\r\n\r\n   \r\n\r\n'
            msg = f"POST /v1/tools/resolve HTTP/1.1\r\nHost: x\r\nX-Verified-Client-ID: {ident}\r\nContent-Type: application/json\r\nContent-Length: {len(b)}\r\n\r\n".encode() + b
        elif kind == "post_crlfcrlf_in_body":
            b = b'{"host":"c.example.com"}' + b"\r\n\r\n" * 3
            msg = f"POST /v1/tools/resolve HTTP/1.1\r\nHost: x\r\nX-Verified-Client-ID: {ident}\r\nContent-Type: application/json\r\nContent-Length: {len(b)}\r\n\r\n".encode() + b
        elif kind == "post_chunked":
            b1, b2 = b'{"host":"ch', b'unk.example.com"}'
            msg = (f"POST /v1/tools/resolve HTTP/1.1\r\nHost: x\r\nX-Verified-Client-ID: {ident}\r\nContent-Type: application/json\r\nTransfer-Encoding: chunked\r\n\r\n"
                   ).encode() + b"%x;ext=1\r\n" % len(b1) + b1 + b"\r\n" + b"%x\r\n" % len(b2) + b2 + b"\r\n0\r\nX-Trailer: t\r\n\r\n"
        else:  # body on a request rejected before reading it (401)
            b = b'{"host":"u.example.com"}'
            msg = f"POST /v1/tools/resolve HTTP/1.1\r\nHost: x\r\nContent-Type: application/json\r\nContent-Length: {len(b)}\r\n\r\n".encode() + b
        s.sendall(msg)
        try:
            r = read_response(f)
        except Exception as e:
            bad.append((i, kind, "exception " + repr(e)))
            break
        if r is None:
            bad.append((i, kind, "connection closed"))
            break
        exp = 401 if kind == "post_unread401" else 200
        if r[0] != exp:
            bad.append((i, kind, r[0]))
    s.close()
    record("B1_400_mixed_valid_requests_one_keepalive_conn_no_false_rejects", not bad, {"first_failures": bad[:5], "n_failures": len(bad)}, cat="http")
    # concurrent connections of the same mix + after-error reuse
    g.stop()


def t_limiter_race(sub):
    g = GW(sub, 1, tag="lrace")
    worst = []
    for trial in range(6):
        ident = uid("lr")
        res = tool("burst", f"127.0.0.1:{g.port}", ident, 40000, 400, timeout=120)
        n200 = res["statuses"].get("200", 0)
        bound = math.floor(5 + 0.5 * res["elapsed"])
        worst.append({"admitted": n200, "elapsed": round(res["elapsed"], 2), "max_allowed": bound})
    over = [w for w in worst if w["admitted"] > w["max_allowed"]]
    record("Q1_limiter_over_admission_under_heavy_concurrency", not over, {"trials": worst, "over": over}, cat="rate")
    g.stop()


def main():
    sub = sys.argv[1]
    which = sys.argv[2].split(",")
    race = len(sys.argv) > 3 and sys.argv[3] == "race"
    if race:
        for k in list(hh.SUBS):
            hh.SUBS[k] = hh.SUBS[k] + "_race"
    os.makedirs(OUT, exist_ok=True)
    fxp = subprocess.Popen([f"{H}/fixture.bin"], stdout=open(f"{OUT}/fixture_x{sub}.log", "wb"), stderr=subprocess.STDOUT)
    time.sleep(0.7)
    try:
        if "memory" in which:
            run_test(t_memory, sub)
        if "mix" in which:
            run_test(t_benign_mix, sub)
        if "lrace" in which:
            run_test(t_limiter_race, sub)
        if "racesuite" in which:
            cl = start_cluster(sub, tag="race")
            try:
                for fn in (t_functional, t_identity, t_rate_basic):
                    run_test(fn)
                # concurrent security corpus hammering
                run_test(t_security)
            finally:
                stop_cluster(cl)
            for fn in (t_logging_exact, t_blocked_sink, t_sink_failure, t_concurrency):
                run_test(fn, sub)
            # mixed concurrent load for 8 s through a 4-replica cluster
            cl = start_cluster(sub, tag="raceload")
            urllib.request.urlopen(FIX + "/ctl/record?on=0").read()
            res = tool("load", BASE, 600, 1, 8, 4000, 3, timeout=60)
            urllib.request.urlopen(FIX + "/ctl/record?on=1").read()
            record("RACE_load_600rps_8s", None, res, cat="race")
            stop_cluster(cl)
            races = 0
            samples = []
            for fnm in os.listdir(OUT):
                if fnm.startswith(sub + "_") and fnm.endswith(".err"):
                    t = open(os.path.join(OUT, fnm), "rb").read()
                    n = t.count(b"WARNING: DATA RACE")
                    if n:
                        races += n
                        samples.append((fnm, t[:600].decode("latin1")))
            record("RACE_detector_warnings", races == 0, {"warnings": races, "samples": samples[:2]}, cat="race")
    finally:
        fxp.kill()
        fxp.wait()
        tag = "race" if race else "x"
        json.dump({"sub": sub, "results": hh.RES}, open(f"{OUT}/result_{sub}_{tag}_{'_'.join(which)}.json", "w"), indent=1, default=str)
        print("done", sub, which)


if __name__ == "__main__":
    main()
