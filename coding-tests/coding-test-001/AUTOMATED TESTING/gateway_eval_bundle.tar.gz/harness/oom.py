#!/usr/bin/env python3
import os, sys, json, time, subprocess, socket, urllib.request
sys.path.insert(0, "/home/claude/h2")
from harness import *
import harness as hh

CG = "/sys/fs/cgroup/memory"

def run_one(sub, trig, n=600, limit=512 << 20):
    d = f"{CG}/gw_{sub}_{trig}"
    os.makedirs(d, exist_ok=True)
    open(f"{d}/memory.limit_in_bytes", "w").write(str(limit))
    try:
        open(f"{d}/memory.memsw.limit_in_bytes", "w").write(str(limit))
    except Exception:
        pass
    e = {"PATH": os.environ["PATH"], "REPLICA_ID": "0", "GATEWAY_ADDR": "127.0.0.1:18080", "SEARCH_BACKEND_URL": "http://127.0.0.1:19001",
         "FILES_BACKEND_URL": "http://127.0.0.1:19002", "RESOLVE_BACKEND_URL": "http://127.0.0.1:19003"}
    def pre():
        open(f"{d}/tasks", "w").write(str(os.getpid()))
    outf = open(f"/tmp/run2/oom_{sub}_{trig}.out", "wb")
    pr = subprocess.Popen([hh.SUBS[sub]], env=e, stdout=outf, stderr=subprocess.DEVNULL, preexec_fn=pre)
    for _ in range(100):
        try:
            socket.create_connection(("127.0.0.1", 18080), timeout=0.2).close(); break
        except OSError:
            time.sleep(0.05)
    res = tool("conc", "127.0.0.1:18080", f"/v1/files/{trig}", n, timeout=120)
    time.sleep(0.5)
    alive = pr.poll() is None
    rc = pr.returncode
    maxu = int(open(f"{d}/memory.max_usage_in_bytes").read()) / 1048576
    fail = int(open(f"{d}/memory.failcnt").read())
    oomk = None
    try:
        for l in open(f"{d}/memory.oom_control"):
            if l.startswith("oom_kill "):
                oomk = int(l.split()[1])
    except Exception:
        pass
    # post-test liveness
    live = False
    if alive:
        try:
            r = req(18080, "GET", "/healthz", ident="probe"); live = r.status == 200
        except Exception:
            pass
    if alive:
        pr.kill()
    pr.wait()
    try:
        os.rmdir(d)
    except Exception:
        pass
    return {"statuses": res["statuses"], "process_alive_after": alive, "returncode": rc, "healthz_after": live, "cgroup_max_usage_MiB": round(maxu, 1), "cgroup_failcnt": fail, "oom_kill_events": oomk}

sub = sys.argv[1]
fxp = subprocess.Popen([f"{H}/fixture.bin"], stdout=subprocess.DEVNULL, stderr=subprocess.STDOUT)
time.sleep(0.7)
urllib.request.urlopen(FIX + "/ctl/record?on=0").read()
out = {}
try:
    for trig in ("drip", "dripchunk"):
        out[trig] = run_one(sub, trig)
finally:
    fxp.kill(); fxp.wait()
json.dump(out, open(f"/tmp/run2/oom_{sub}.json", "w"), indent=1)
print(sub, json.dumps(out))
