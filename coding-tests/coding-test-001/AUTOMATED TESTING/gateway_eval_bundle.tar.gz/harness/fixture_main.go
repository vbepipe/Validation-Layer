package main

import (
	"bytes"
	"encoding/json"
	"io"
	"net"
	"net/http"
	"os"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"time"
)

type rec struct {
	Backend string              `json:"backend"`
	Method  string              `json:"method"`
	URI     string              `json:"uri"`
	Headers map[string][]string `json:"headers"`
	Body    string              `json:"body"`
}

var (
	mu        sync.Mutex
	recs      []rec
	recording atomic.Bool
	delayUS   atomic.Int64
	cancelled atomic.Int64
	counts    [3]atomic.Int64
	names     = []string{"search", "files", "resolve"}
)

func chunks(w http.ResponseWriter, n int) {
	fl, _ := w.(http.Flusher)
	buf := bytes.Repeat([]byte("x"), 32<<10)
	w.Header().Set("Content-Type", "application/octet-stream")
	for n > 0 {
		k := len(buf)
		if k > n {
			k = n
		}
		if _, err := w.Write(buf[:k]); err != nil {
			return
		}
		if fl != nil {
			fl.Flush()
		}
		n -= k
	}
}

func fixed(w http.ResponseWriter, n int) {
	w.Header().Set("Content-Length", strconv.Itoa(n))
	w.Header().Set("Content-Type", "application/octet-stream")
	w.WriteHeader(200)
	buf := bytes.Repeat([]byte("x"), 32<<10)
	for n > 0 {
		k := len(buf)
		if k > n {
			k = n
		}
		if _, err := w.Write(buf[:k]); err != nil {
			return
		}
		n -= k
	}
}

func sleepCtx(r *http.Request, d time.Duration) bool {
	t := time.NewTimer(d)
	defer t.Stop()
	select {
	case <-t.C:
		return true
	case <-r.Context().Done():
		cancelled.Add(1)
		return false
	}
}

func handler(idx int) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		body, _ := io.ReadAll(io.LimitReader(r.Body, 1<<20))
		counts[idx].Add(1)
		if recording.Load() {
			h := map[string][]string{}
			for k, v := range r.Header {
				h[strings.ToLower(k)] = v
			}
			mu.Lock()
			recs = append(recs, rec{names[idx], r.Method, r.RequestURI, h, string(body)})
			mu.Unlock()
		}
		key := ""
		switch idx {
		case 0:
			key = r.URL.Query().Get("q")
		case 1:
			p := r.URL.Path
			key = p[strings.LastIndex(p, "/")+1:]
		case 2:
			var o struct{ Host string }
			_ = json.Unmarshal(body, &o)
			key = strings.Split(o.Host, ".")[0]
		}
		key = strings.ToLower(key)
		if d := delayUS.Load(); d > 0 {
			time.Sleep(time.Duration(d) * time.Microsecond)
		}
		switch key {
		case "slow":
			if !sleepCtx(r, 3200*time.Millisecond) {
				return
			}
		case "s15":
			if !sleepCtx(r, 1500*time.Millisecond) {
				return
			}
		case "big":
			fixed(w, 2<<20)
			return
		case "bigchunk":
			chunks(w, 2<<20)
			return
		case "exact":
			fixed(w, 1<<20)
			return
		case "over1":
			fixed(w, 1<<20+1)
			return
		case "exactchunk":
			chunks(w, 1<<20)
			return
		case "over1chunk":
			chunks(w, 1<<20+1)
			return
		case "err500":
			w.WriteHeader(500)
			io.WriteString(w, "boom internal secret detail")
			return
		case "reset":
			hj, _ := w.(http.Hijacker)
			c, _, _ := hj.Hijack()
			c.Close()
			return
		case "e404":
			w.Header().Set("X-Custom", "v")
			w.WriteHeader(404)
			io.WriteString(w, "fixture-not-found")
			return
		case "etag":
			w.Header().Set("ETag", `"v1"`)
			if r.Header.Get("If-None-Match") == `"v1"` {
				w.WriteHeader(304)
				return
			}
		case "drip", "dripchunk":
			fl, _ := w.(http.Flusher)
			if key == "drip" {
				w.Header().Set("Content-Length", strconv.Itoa(1<<20))
			}
			w.WriteHeader(200)
			chunk := bytes.Repeat([]byte("x"), 64<<10)
			for i := 0; i < 16; i++ {
				if _, err := w.Write(chunk); err != nil {
					return
				}
				if fl != nil {
					fl.Flush()
				}
				time.Sleep(60 * time.Millisecond)
			}
			return
		case "hop2":
			w.Header().Set("Connection", "X-Hop2")
			w.Header().Set("X-Hop2", "1")
			w.Header().Set("X-Custom", "v")
		case "hop":
			w.Header().Set("Connection", "close, X-Hop")
			w.Header().Set("X-Hop", "1")
			w.Header().Set("Keep-Alive", "timeout=5")
			w.Header().Set("X-Custom", "v")
			w.Header().Set("Set-Cookie", "a=b")
		}
		w.Header().Set("Content-Type", "application/json")
		io.WriteString(w, `{"ok":true,"backend":"`+names[idx]+`","pad":"xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"}`)
	}
}

func main() {
	base := 19000
	recording.Store(true)
	for i := 0; i < 3; i++ {
		ln, err := net.Listen("tcp", "127.0.0.1:"+strconv.Itoa(base+1+i))
		if err != nil {
			panic(err)
		}
		srv := &http.Server{Handler: handler(i)}
		go srv.Serve(ln)
	}
	mux := http.NewServeMux()
	mux.HandleFunc("/ctl/log", func(w http.ResponseWriter, r *http.Request) {
		mu.Lock()
		out := map[string]any{"recs": recs, "counts": []int64{counts[0].Load(), counts[1].Load(), counts[2].Load()}, "cancelled": cancelled.Load()}
		b, _ := json.Marshal(out)
		mu.Unlock()
		w.Write(b)
	})
	mux.HandleFunc("/ctl/stats", func(w http.ResponseWriter, r *http.Request) {
		b, _ := json.Marshal(map[string]any{"counts": []int64{counts[0].Load(), counts[1].Load(), counts[2].Load()}, "cancelled": cancelled.Load()})
		w.Write(b)
	})
	mux.HandleFunc("/ctl/reset", func(w http.ResponseWriter, r *http.Request) {
		mu.Lock()
		recs = nil
		mu.Unlock()
		for i := range counts {
			counts[i].Store(0)
		}
		cancelled.Store(0)
		w.Write([]byte("ok"))
	})
	mux.HandleFunc("/ctl/delay", func(w http.ResponseWriter, r *http.Request) {
		n, _ := strconv.Atoi(r.URL.Query().Get("us"))
		delayUS.Store(int64(n))
		w.Write([]byte("ok"))
	})
	mux.HandleFunc("/ctl/record", func(w http.ResponseWriter, r *http.Request) {
		recording.Store(r.URL.Query().Get("on") == "1")
		w.Write([]byte("ok"))
	})
	if len(os.Args) > 1 {
		base = 19000
	}
	ln, err := net.Listen("tcp", "127.0.0.1:19000")
	if err != nil {
		panic(err)
	}
	http.Serve(ln, mux)
}
