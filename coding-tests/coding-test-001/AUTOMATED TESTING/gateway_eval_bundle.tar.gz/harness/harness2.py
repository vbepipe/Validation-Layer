#!/usr/bin/env python3
from harness import *
import harness as hh
import fcntl, shutil

REQ_KEYS = ["request_id", "event_id", "timestamp", "method", "route", "status", "duration_ms", "outcome", "reason", "client_id"]
MARKERS = [b"SECRETQUERYMARK", b"FILEPATHMARK", b"bodymark", b"AUTHMARK", b"COOKIEMARK", b"IDENTMARK", b"HDRMARK", b"evilPATHMARK2", b"injected", b"BADHOSTMARK"]


def lines_of(b):
    return [l for l in b.split(b"\n") if l != b""]


# ---------------------------------------------------------------------
def t_logging_exact(sub):
    fx_reset()
    g = GW(sub, 0, tag="log")
    p = g.port
    observed = []   # statuses for non-exempt requests

    def do(*a, **k):
        r = req(p, *a, **k)
        observed.append(r.status)
        return r

    ident = lambda: "IDENTMARK" + uid("")
    # valid with markers in every user-controlled place
    do("GET", "/v1/search?q=SECRETQUERYMARK", ident=ident(), headers=[("Authorization", "Bearer AUTHMARK"), ("Cookie", "s=COOKIEMARK"), ("X-Foo", "HDRMARK")])
    do("GET", "/v1/files/FILEPATHMARK", ident=ident())
    do("POST", "/v1/tools/resolve", ident=ident(), headers=RESOLVE_CT, body='{"host":"bodymark.example.com"}')
    for _ in range(3):
        do("GET", "/v1/search?q=ok", ident=ident())
    # invalid requests with injection payloads
    do("GET", "/v1/search?q=%0A%7B%22injected%22%3Atrue%7D", ident=ident())
    do("GET", "/v1/search?q=%", ident=ident())
    do("GET", "/v1/files/..%2fBADHOSTMARK", ident=ident())
    do("POST", "/v1/tools/resolve", ident=ident(), headers=RESOLVE_CT, body='{"host":"a.com","host":"BADHOSTMARK"}')
    do("GET", "/evilPATHMARK2%0A%7B%22injected%22:1%7D", ident=ident())
    do("GET", "/nope", ident=ident())
    do("POST", "/v1/search?q=a", ident=ident(), body="")
    do("DELETE", "/v1/files/abc", ident=ident())
    do("GET", "/v1/search?q=a", ident=None)
    do("GET", "/v1/tools/resolve", ident="bad ident")
    # method with unusual token chars
    do("FOO-BAR", "/v1/search?q=a", ident=ident())
    # quota exhaustion
    q = ident()
    for _ in range(8):
        do("GET", "/v1/search?q=a", ident=q)
    # upstream failures
    do("GET", "/v1/files/reset", ident=ident())
    do("GET", "/v1/files/over1", ident=ident(), timeout=8)
    do("GET", "/v1/search?q=slow", ident=ident(), timeout=8)
    # oversized body
    do("POST", "/v1/tools/resolve", ident=ident(), headers=RESOLVE_CT, body=b'{"host":"a.com"}' + b" " * 70000)
    # exempt: health/metrics (with and without identity), parser failures
    for _ in range(3):
        req(p, "GET", "/healthz", ident=None)
    req(p, "GET", "/healthz", ident=ident())
    req(p, "GET", "/_internal/metrics", ident=None)
    req(p, "GET", "/_internal/metrics", ident=ident())
    send_raw(p, b"GARBAGE\r\n\r\n", timeout=1)
    send_raw(p, b"GET /v1/search?q=a HTTP/1.1\r\nHost x\r\n\r\n", timeout=1)
    time.sleep(1.2)
    out = g.stdout_text()
    err = open(g.err_path, "rb").read()
    L = lines_of(out)
    parsed, bad_json, missing = [], 0, []
    for l in L:
        try:
            o = json.loads(l)
            parsed.append(o)
            miss = [k for k in REQ_KEYS if k not in o]
            if miss:
                missing.append(miss)
        except Exception:
            bad_json += 1
    expected = len([s for s in observed if s])
    too_big = [len(l) for l in L if len(l) + 1 > 2048]
    ids_unique = len({o.get("event_id") for o in parsed}) == len(parsed) and len({o.get("request_id") for o in parsed}) == len(parsed)
    leaked = [m.decode() for m in MARKERS if m in out or m in err]
    logged_status = sorted(o.get("status") for o in parsed)
    obs_status = sorted(s for s in observed if s)
    raw_ident_logged = any(b'"client_id":"IDENTMARK' in l for l in L)
    record("L1_exactly_one_json_event_per_application_request", bad_json == 0 and len(parsed) == expected and not missing,
           {"expected_events": expected, "stdout_lines": len(L), "bad_json_lines": bad_json, "missing_fields": missing[:2]}, cat="log")
    record("L2_logged_status_matches_response_status", logged_status == obs_status, {"logged_not_in_observed": [s for s in logged_status if s not in obs_status][:5], "observed_not_logged": [s for s in obs_status if s not in logged_status][:5],
           "logged_hist": {str(k): logged_status.count(k) for k in set(logged_status)}, "obs_hist": {str(k): obs_status.count(k) for k in set(obs_status)}}, cat="log")
    record("L3_no_user_values_secrets_or_injection_in_stdout_stderr", not leaked and not raw_ident_logged, {"leaked_markers": leaked, "raw_identity_in_client_id": raw_ident_logged}, cat="log")
    record("L4_events_le_2KiB_and_unique_ids", not too_big and ids_unique, {"oversize": too_big, "ids_unique": ids_unique}, cat="log")
    record("L5_stderr_clean_of_stack_traces", b"goroutine" not in err and b"panic" not in err, {"stderr_len": len(err)}, cat="log")
    # metrics shape
    r = req(p, "GET", "/_internal/metrics", ident=None)
    r2 = req(p, "GET", "/_internal/metrics", ident="metricsprobe")
    record("L6_metrics_counters_present(info)", None, {"no_ident": (r.status, r.body[:160].decode("latin1")), "with_ident": (r2.status, r2.body[:160].decode("latin1"))}, cat="info")
    g.stop()


# ---------------------------------------------------------------------
def count_lines_nonblocking(fd, secs):
    fl = fcntl.fcntl(fd, fcntl.F_GETFL)
    fcntl.fcntl(fd, fcntl.F_SETFL, fl | os.O_NONBLOCK)
    total, buf = 0, b""
    bad = 0
    end = time.time() + secs
    quiet_since = time.time()
    while time.time() < end:
        r, _, _ = select.select([fd], [], [], 0.1)
        if r:
            try:
                d = os.read(fd, 1 << 20)
            except BlockingIOError:
                continue
            if not d:
                break
            quiet_since = time.time()
            buf += d
            *ls, buf = buf.split(b"\n")
            for l in ls:
                if l:
                    try:
                        json.loads(l)
                        total += 1
                    except Exception:
                        bad += 1
        elif time.time() - quiet_since > 1.0:
            break
    return total, bad


def t_blocked_sink(sub):
    rfd, wfd = os.pipe()
    fx_reset()
    g = GW(sub, 1, stdout=wfd, tag="blk")
    os.close(wfd)
    p = g.port
    pre_rss = g.rss_hwm_kb()
    N = 9800
    res = tool("flood", f"127.0.0.1:{p}", N, 64, "blk" + uid("") + "_", timeout=180)
    st = res["statuses"]
    stats = fx_stats()
    n200, n503 = st.get("200", 0), st.get("503", 0)
    m = req(p, "GET", "/_internal/metrics", ident="metricsprobe")
    mj = None
    try:
        mj = json.loads(m.body)
    except Exception:
        pass
    rss = g.rss_hwm_kb()
    thr = g.threads()
    h = req(p, "GET", "/healthz", ident=None).status
    record("L7_blocked_sink_saturation_returns_503_without_backend_contact",
           n503 > 0 and stats["counts"][0] == n200 and n200 <= 8192 + 400 and g.alive(),
           {"statuses": st, "backend_contacts": stats["counts"][0], "n200": n200, "n503": n503, "alive": g.alive(), "healthz_during_block": h, "metrics": mj,
            "metrics_status": m.status, "rss_hwm_mb": round((rss or 0) / 1024, 1), "threads": thr, "elapsed": round(res["elapsed"], 2)}, cat="log")
    # now drain the pipe: every reserved request must produce exactly one event
    got, bad = count_lines_nonblocking(rfd, 12)
    reserved_requests = N - n503
    record("L8_blocked_sink_no_event_lost_after_unblock", got == reserved_requests and bad == 0,
           {"events_read_after_unblock": got, "bad_lines": bad, "requests_that_reserved(non-503)": reserved_requests, "n503": n503},
           "all non-503 requests reserved a slot, so exactly that many events must eventually appear", cat="log")
    time.sleep(0.5)
    m2 = req(p, "GET", "/_internal/metrics", ident="metricsprobe")
    # after unblock: service should recover
    r = req(p, "GET", "/v1/search?q=a")
    record("L9_service_recovers_after_sink_unblocks", r.status == 200, {"status": r.status, "metrics_after": m2.body[:200].decode("latin1")}, cat="log")
    os.close(rfd)
    g.stop()
    # stalled-sink shutdown timing: fill pipe + queue, then SIGTERM
    rfd, wfd = os.pipe()
    g = GW(sub, 1, stdout=wfd, tag="blk2")
    os.close(wfd)
    tool("flood", f"127.0.0.1:{g.port}", 1500, 64, "blk2" + uid("") + "_", timeout=60)
    t0 = time.time()
    g.proc.send_signal(signal.SIGTERM)
    try:
        g.proc.wait(timeout=6)
        dt = time.time() - t0
        rc = g.proc.returncode
    except Exception:
        dt, rc = None, None
        g.proc.kill()
    record("L10_sigterm_with_stalled_stdout_exits_within_3s", dt is not None and dt <= 3.05, {"exit_after_s": None if dt is None else round(dt, 3), "returncode": rc}, cat="log")
    os.close(rfd)
    g.stop()
    # worst case: stalled stdout AND a stuck in-flight request at SIGTERM
    rfd, wfd = os.pipe()
    g = GW(sub, 1, stdout=wfd, tag="blk3")
    os.close(wfd)
    tool("flood", f"127.0.0.1:{g.port}", 1500, 64, "blk3" + uid("") + "_", timeout=60)
    s = socket.create_connection(("127.0.0.1", g.port), timeout=5)
    s.sendall(f"POST /v1/tools/resolve HTTP/1.1\r\nHost: x\r\nX-Verified-Client-ID: {uid()}\r\nContent-Type: application/json\r\nContent-Length: 30\r\n\r\n{{\"host\"".encode())
    time.sleep(0.4)
    t0 = time.time()
    g.proc.send_signal(signal.SIGTERM)
    try:
        g.proc.wait(timeout=8)
        dt = time.time() - t0
    except Exception:
        dt = None
        g.proc.kill()
    s.close()
    record("SD4_stalled_stdout_plus_stuck_request_exit_le_3s", dt is not None and dt <= 3.0, {"exit_after_s": None if dt is None else round(dt, 3)}, cat="log")
    os.close(rfd)
    g.stop()


# ---------------------------------------------------------------------
def t_concurrency(sub):
    fx_reset()
    g = GW(sub, 0, tag="conc")
    p = g.port
    N = 700
    results = [None] * N

    def worker(i):
        r = req(p, "GET", "/v1/files/s15", ident=uid("cc"), timeout=9)
        results[i] = r.status
    ths = [threading.Thread(target=worker, args=(i,)) for i in range(N)]
    for t in ths:
        t.start()
    for t in ths:
        t.join()
    st = {}
    for s_ in results:
        st[str(s_)] = st.get(str(s_), 0) + 1
    stats = fx_stats()
    time.sleep(1.0)
    ev = lines_of(g.stdout_text())
    n200 = st.get("200", 0)
    n503 = st.get("503", 0)
    record("K1_512_concurrent_cap_honored_not_stricter",
           500 <= n200 <= 512 and stats["counts"][1] == n200 and n200 + n503 == N,
           {"statuses": st, "backend_contacts": stats["counts"][1], "events_logged": len(ev), "threads": g.threads(), "rss_hwm_mb": round((g.rss_hwm_kb() or 0) / 1024, 1)},
           "spec: at most 512 in active processing; excess 503 w/o backend contact. n200 << 512 means stricter-than-spec admission", cat="log")
    record("K2_every_request_including_503_has_one_event", len(ev) == N, {"events": len(ev), "requests": N}, cat="log")
    g.stop()


# ---------------------------------------------------------------------
def t_shutdown(sub):
    # (a) in-flight request completes after SIGTERM; exit prompt after; event delivered
    fx_reset()
    g = GW(sub, 2, tag="sd1")
    res = {}

    def inflight():
        r = req(g.port, "GET", "/v1/files/s15", timeout=6)
        res["status"] = r.status
        res["t"] = time.time()
    th = threading.Thread(target=inflight)
    t0 = time.time()
    th.start()
    time.sleep(0.4)
    g.proc.send_signal(signal.SIGTERM)
    tsig = time.time()
    try:
        g.proc.wait(timeout=6)
        texit = time.time() - tsig
    except Exception:
        texit = None
        g.proc.kill()
    th.join()
    out = lines_of(g.stdout_text())
    evs = []
    for l in out:
        try:
            evs.append(json.loads(l))
        except Exception:
            pass
    ev_ok = [e for e in evs if e.get("route") == "/v1/files/{file_id}" and e.get("status") == 200]
    record("SD1_inflight_request_finishes_after_sigterm_and_event_delivered",
           res.get("status") == 200 and len(ev_ok) == 1 and texit is not None and texit < 3.0,
           {"inflight_status": res.get("status"), "exit_after_signal_s": None if texit is None else round(texit, 2), "events_for_inflight": len(ev_ok), "total_events": len(evs)}, cat="log")
    g.stop()
    # (b) keep-alive: new dispatch refused after SIGTERM
    fx_reset()
    g = GW(sub, 2, tag="sd2")
    s = socket.create_connection(("127.0.0.1", g.port), timeout=5)
    s.sendall(f"GET /v1/search?q=a HTTP/1.1\r\nHost: x\r\nX-Verified-Client-ID: {uid()}\r\n\r\n".encode())
    first = parse_resp(recv_all(s, 0.5))
    before = fx_stats()["counts"][0]
    g.proc.send_signal(signal.SIGTERM)
    time.sleep(0.15)
    second = Resp()
    try:
        s.sendall(f"GET /v1/search?q=b HTTP/1.1\r\nHost: x\r\nX-Verified-Client-ID: {uid()}\r\n\r\n".encode())
        second = parse_resp(recv_all(s, 1.0))
    except Exception as e:
        second = Resp(0, err=repr(e))
    s.close()
    after = fx_stats()["counts"][0]
    try:
        g.proc.wait(timeout=5)
    except Exception:
        g.proc.kill()
    # new connection after signal
    try:
        c = socket.create_connection(("127.0.0.1", g.port), timeout=0.5)
        c.close()
        newconn = "accepted"
    except OSError:
        newconn = "refused"
    record("SD2_keepalive_request_after_sigterm_not_dispatched", first.status == 200 and after == before,
           {"first": first.status, "second_after_sigterm": second.status, "backend_contacts_before/after": (before, after), "new_connection_after_exit": newconn}, cat="log")
    g.stop()
    # (c) stuck slow-body request: must be cancelled and process exit <= 3s after SIGTERM
    g = GW(sub, 2, tag="sd3")
    s = socket.create_connection(("127.0.0.1", g.port), timeout=5)
    s.sendall(f"POST /v1/tools/resolve HTTP/1.1\r\nHost: x\r\nX-Verified-Client-ID: {uid()}\r\nContent-Type: application/json\r\nContent-Length: 30\r\n\r\n{{\"host\"".encode())
    time.sleep(0.4)
    g.proc.send_signal(signal.SIGTERM)
    tsig = time.time()
    try:
        g.proc.wait(timeout=8)
        texit = time.time() - tsig
        rc = g.proc.returncode
    except Exception:
        texit, rc = None, None
        g.proc.kill()
    s.close()
    record("SD3_stuck_request_cancelled_exit_le_3s", texit is not None and texit <= 3.0, {"exit_after_signal_s": None if texit is None else round(texit, 3), "returncode": rc}, cat="log")
    g.stop()


# ---------------------------------------------------------------------
def t_sink_failure(sub):
    # (a) /dev/full: write errors (ENOSPC) without SIGPIPE
    fx_reset()
    devfull = open("/dev/full", "wb")
    g = GW(sub, 2, stdout=devfull, tag="full")
    p = g.port
    r1 = req(p, "GET", "/v1/search?q=a").status
    time.sleep(0.4)
    alive1 = g.alive()
    r2 = req(p, "GET", "/v1/search?q=a").status if alive1 else None
    before = fx_stats()["counts"][0]
    r3 = req(p, "GET", "/v1/files/abc").status if alive1 else None
    after = fx_stats()["counts"][0]
    m = req(p, "GET", "/_internal/metrics", ident="metricsprobe") if alive1 else Resp()
    m_nid = req(p, "GET", "/_internal/metrics", ident=None) if alive1 else Resp()
    mj = None
    for mm in (m, m_nid):
        try:
            mj = json.loads(mm.body)
            break
        except Exception:
            pass
    delivered_fail = None
    if isinstance(mj, dict):
        for k, v in mj.items():
            if "delivery" in k:
                delivered_fail = v
    record("L11_write_error_marks_unhealthy_fails_closed_503", alive1 and r2 == 503 and r3 == 503 and before == after,
           {"first_request": r1, "second": r2, "third": r3, "backend_contacts_during_failed_state": after - before, "alive": alive1}, cat="log")
    record("L12_write_error_increments_delivery_failure_metric_readable", delivered_fail is not None and delivered_fail >= 1,
           {"metrics_with_ident": (m.status, m.body[:200].decode("latin1")), "metrics_without_ident": (m_nid.status, m_nid.body[:120].decode("latin1")), "delivery_failure_value": delivered_fail}, cat="log")
    g.stop()
    devfull.close()
    # (b) closed pipe: EPIPE/SIGPIPE
    rfd, wfd = os.pipe()
    os.close(rfd)
    g = GW(sub, 2, stdout=wfd, tag="pipe")
    os.close(wfd)
    p = g.port
    r1 = req(p, "GET", "/v1/search?q=a").status
    time.sleep(0.5)
    alive = g.alive()
    sig = None
    if not alive:
        rc = g.proc.returncode
        sig = f"returncode={rc}"
    r2 = req(p, "GET", "/v1/search?q=a").status if alive else None
    m = req(p, "GET", "/_internal/metrics", ident="metricsprobe") if alive else Resp()
    record("L13_closed_stdout_pipe_process_survives_and_fails_closed", alive and r2 == 503,
           {"first_request": r1, "alive_after_first_write": alive, "second": r2, "exit_info": sig, "metrics": (m.status, m.body[:160].decode("latin1"))}, cat="log")
    g.stop()


# ---------------------------------------------------------------------
def t_config(sub):
    base = {"REPLICA_ID": "0", "GATEWAY_ADDR": "127.0.0.1:18099", "SEARCH_BACKEND_URL": "http://127.0.0.1:19001", "FILES_BACKEND_URL": "http://127.0.0.1:19002",
            "RESOLVE_BACKEND_URL": "http://127.0.0.1:19003"}
    cases = {
        "missing_replica": {"REPLICA_ID": None}, "replica_4": {"REPLICA_ID": "4"}, "replica_01": {"REPLICA_ID": "01"}, "missing_search": {"SEARCH_BACKEND_URL": None},
        "url_with_path": {"FILES_BACKEND_URL": "http://127.0.0.1:19002/x"}, "url_with_query": {"FILES_BACKEND_URL": "http://127.0.0.1:19002?x=1"},
        "url_userinfo": {"RESOLVE_BACKEND_URL": "http://u:p@127.0.0.1:19003"}, "url_https": {"RESOLVE_BACKEND_URL": "https://127.0.0.1:19003"}, "url_fragment": {"SEARCH_BACKEND_URL": "http://127.0.0.1:19001#x"},
    }
    obs, bad = {}, []
    for name, mod in cases.items():
        e = dict(base)
        e.update(mod)
        e = {k: v for k, v in e.items() if v is not None}
        e["PATH"] = os.environ["PATH"]
        pr = subprocess.Popen([SUBS[sub]], env=e, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        try:
            out, err = pr.communicate(timeout=1.5)
            rc = pr.returncode
        except subprocess.TimeoutExpired:
            pr.kill()
            out, err = pr.communicate()
            rc = "RUNNING"
        obs[name] = {"rc": rc, "stderr": err[:100].decode("latin1"), "stdout_len": len(out)}
        if rc in (0, "RUNNING") or b"goroutine" in err or b"panic" in err or out:
            bad.append(name)
    record("C1_invalid_config_rejected_cleanly_no_stack_traces", not bad, {"accepted_or_dirty": bad, "detail": {k: obs[k]["rc"] for k in obs}}, cat="cfg")
    # trailing slash: informational
    e = dict(base)
    e["FILES_BACKEND_URL"] = "http://127.0.0.1:19002/"
    e["PATH"] = os.environ["PATH"]
    pr = subprocess.Popen([SUBS[sub]], env=e, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    try:
        pr.communicate(timeout=1.0)
        trailing = f"exited rc={pr.returncode}"
    except subprocess.TimeoutExpired:
        pr.kill()
        trailing = "accepted (running)"
    record("C2_trailing_slash_origin(info)", None, {"result": trailing}, "spec: 'no path'; '/' is arguably an empty path", cat="info")
    # default listen address
    e = dict(base)
    del e["GATEWAY_ADDR"]
    e["PATH"] = os.environ["PATH"]
    pr = subprocess.Popen([SUBS[sub]], env=e, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    time.sleep(0.5)
    try:
        socket.create_connection(("127.0.0.1", 8080), timeout=0.5).close()
        okdef = True
    except OSError:
        okdef = False
    pr.kill()
    pr.wait()
    record("C3_default_addr_127.0.0.1:8080", okdef, {"connect": okdef}, cat="cfg")
    # no secrets / hardcoded credentials in binary source
    src = open(f"/home/claude/{sub}/main.go").read()
    sus = re.findall(r'(?i)(password|secret|api[_-]?key|token)\s*[:=]\s*"[^"]{4,}"', src)
    record("C4_no_hardcoded_credentials_in_source", not sus, {"matches": sus[:3]}, cat="cfg")


# ---------------------------------------------------------------------
def cpu_ticks(pid):
    try:
        f = open(f"/proc/{pid}/stat").read().rsplit(")", 1)[1].split()
        return int(f[11]) + int(f[12])
    except Exception:
        return None


def t_perf(sub):
    urllib.request.urlopen(FIX + "/ctl/delay?us=250").read()
    urllib.request.urlopen(FIX + "/ctl/record?on=0").read()
    fx_reset()
    gws = start_cluster(sub, tag="perf")
    # tiny warm-up of connections
    for i in range(4):
        req(gws[i].port, "GET", "/v1/search?q=warm", ident="warm" + str(i))
    clk = os.sysconf("SC_CLK_TCK")
    t0 = [cpu_ticks(g.proc.pid) for g in gws]
    res = tool("load", BASE, 2000, 5, 30, 4000, 1, timeout=120)
    t1 = [cpu_ticks(g.proc.pid) for g in gws]
    rss = [g.rss_hwm_kb() for g in gws]
    thr = [g.threads() for g in gws]
    alive = all(g.alive() for g in gws)
    time.sleep(1.0)
    ev = sum(len(lines_of(g.stdout_text())) for g in gws)
    cpu_s = sum((b - a) for a, b in zip(t0, t1) if a is not None and b is not None) / clk
    total_req = (5 + 30) * 2000 + 4
    out = {"load": res, "rss_hwm_mb_each": [round((r or 0) / 1024, 1) for r in rss], "rss_hwm_mb_max": round(max(r or 0 for r in rss) / 1024, 1),
           "rss_sum_mb": round(sum(r or 0 for r in rss) / 1024, 1), "threads": thr, "alive": alive, "gateway_cpu_s_total": round(cpu_s, 1),
           "events_written": ev, "requests_sent": total_req}
    record("P1_open_loop_2000rps_70_20_10", None, out, cat="perf")
    stop_cluster(gws)
    urllib.request.urlopen(FIX + "/ctl/delay?us=0").read()
    urllib.request.urlopen(FIX + "/ctl/record?on=1").read()
    # repeat perf a second time for noise estimate
    urllib.request.urlopen(FIX + "/ctl/delay?us=250").read()
    urllib.request.urlopen(FIX + "/ctl/record?on=0").read()
    gws = start_cluster(sub, tag="perf2")
    for i in range(4):
        req(gws[i].port, "GET", "/v1/search?q=warm", ident="warm" + str(i))
    res2 = tool("load", BASE, 2000, 5, 30, 4000, 2, timeout=120)
    rss2 = [g.rss_hwm_kb() for g in gws]
    record("P2_open_loop_repeat_seed2", None, {"load": res2, "rss_hwm_mb_max": round(max(r or 0 for r in rss2) / 1024, 1)}, cat="perf")
    stop_cluster(gws)
    urllib.request.urlopen(FIX + "/ctl/delay?us=0").read()
    urllib.request.urlopen(FIX + "/ctl/record?on=1").read()


# ---------------------------------------------------------------------
def main():
    sub = sys.argv[1]
    only = sys.argv[2].split(",") if len(sys.argv) > 2 else None
    os.makedirs(OUT, exist_ok=True)
    fxp = subprocess.Popen([f"{H}/fixture.bin"], stdout=open(f"{OUT}/fixture_{sub}.log", "wb"), stderr=subprocess.STDOUT)
    time.sleep(0.7)
    t_start = time.time()
    try:
        def want(n):
            return only is None or n in only
        if any(want(n) for n in ("functional", "security", "identity", "http", "rate_basic", "rate_cluster")):
            cluster = start_cluster(sub, tag="main")
            try:
                if want("functional"):
                    run_test(t_functional)
                if want("security"):
                    run_test(t_security)
                if want("identity"):
                    run_test(t_identity)
                if want("http"):
                    run_test(t_http_boundary)
                if want("rate_basic"):
                    run_test(t_rate_basic)
                if want("rate_cluster"):
                    run_test(t_rate_cluster)
            finally:
                stop_cluster(cluster)
        if want("cap"):
            g = GW(sub, 3, tag="cap")
            hh.BASE = BASE
            try:
                run_test(t_state_cap)
            finally:
                g.stop()
        if want("logging"):
            run_test(t_logging_exact, sub)
        if want("blocked"):
            run_test(t_blocked_sink, sub)
        if want("concurrency"):
            run_test(t_concurrency, sub)
        if want("shutdown"):
            run_test(t_shutdown, sub)
        if want("sink"):
            run_test(t_sink_failure, sub)
        if want("config"):
            run_test(t_config, sub)
        if want("perf"):
            run_test(t_perf, sub)
    finally:
        fxp.kill()
        fxp.wait()
        json.dump({"sub": sub, "secs": round(time.time() - t_start, 1), "results": hh.RES}, open(f"{OUT}/result_{sub}_r2.json", "w"), indent=1, default=str)
        print("done", sub, round(time.time() - t_start, 1))


if __name__ == "__main__":
    main()
