#!/usr/bin/env python3
import math, json, os, re, signal, socket, subprocess, sys, threading, time, urllib.request, traceback, itertools, select

H = "/home/claude/h"
SUBS = {"orig": "/home/claude/orig/gateway", "rev": "/home/claude/rev/gateway",
        "v1": "/home/claude/v1/gateway", "v2": "/home/claude/v2/gateway"}
BASE = 18080
FIX = "http://127.0.0.1:19000"
OUT = "/tmp/run2"
_counter = itertools.count(1)
RES = {}


def uid(p="t"):
    return f"{p}{os.getpid()}x{next(_counter)}"


# ---------------- fixture control ----------------
def fx(path):
    return json.loads(urllib.request.urlopen(FIX + path, timeout=10).read() or b"{}") if "reset" not in path and "delay" not in path and "record" not in path else urllib.request.urlopen(FIX + path, timeout=10).read()


def fx_reset():
    urllib.request.urlopen(FIX + "/ctl/reset", timeout=10).read()


def fx_log():
    d = json.loads(urllib.request.urlopen(FIX + "/ctl/log", timeout=20).read())
    d["recs"] = d["recs"] or []
    return d


def fx_stats():
    return json.loads(urllib.request.urlopen(FIX + "/ctl/stats", timeout=10).read())


# ---------------- raw http ----------------
class Resp:
    def __init__(self, status=0, headers=None, body=b"", raw=b"", err=None):
        self.status, self.headers, self.body, self.raw, self.err = status, headers or [], body, raw, err

    def h(self, name):
        return [v for k, v in self.headers if k.lower() == name.lower()]


def parse_resp(raw):
    if b"\r\n\r\n" not in raw:
        return Resp(0, [], b"", raw, "incomplete")
    head, body = raw.split(b"\r\n\r\n", 1)
    lines = head.split(b"\r\n")
    try:
        status = int(lines[0].split()[1])
    except Exception:
        return Resp(0, [], body, raw, "badstatus")
    hdrs = []
    for l in lines[1:]:
        if b":" in l:
            k, v = l.split(b":", 1)
            hdrs.append((k.decode("latin1"), v.strip().decode("latin1")))
    te = [v for k, v in hdrs if k.lower() == "transfer-encoding"]
    if te and "chunked" in te[0].lower():
        out = b""
        rest = body
        while rest:
            if b"\r\n" not in rest:
                break
            sz, rest = rest.split(b"\r\n", 1)
            try:
                n = int(sz.split(b";")[0], 16)
            except Exception:
                break
            if n == 0:
                break
            out += rest[:n]
            rest = rest[n + 2:]
        body = out
    return Resp(status, hdrs, body, raw)


def recv_all(s, timeout):
    s.settimeout(timeout)
    buf = b""
    end = time.time() + timeout
    while time.time() < end:
        try:
            d = s.recv(65536)
        except socket.timeout:
            break
        except (ConnectionResetError, OSError):
            break
        if not d:
            break
        buf += d
    return buf


def send_raw(port, data, timeout=5, host="127.0.0.1"):
    s = socket.create_connection((host, port), timeout=5)
    try:
        try:
            s.sendall(data)
        except (BrokenPipeError, ConnectionResetError, OSError):
            pass
        raw = recv_all(s, timeout)
    finally:
        s.close()
    return parse_resp(raw)


def req(port, method, target, headers=None, body=None, ident="auto", timeout=6, extra_raw=b"", host=None, version="HTTP/1.1"):
    """Build a raw HTTP/1.1 request. ident: 'auto' | None | str | list[str]"""
    hs = []
    hs.append(("Host", host or f"127.0.0.1:{port}"))
    if ident == "auto":
        ident = uid()
    if ident is not None:
        for i in ([ident] if isinstance(ident, str) else ident):
            hs.append(("X-Verified-Client-ID", i))
    for k, v in (headers or []):
        hs.append((k, v))
    data = body if isinstance(body, (bytes, bytearray)) else (body.encode() if body else b"")
    if body is not None and not any(k.lower() == "content-length" for k, _ in hs) and not any(k.lower() == "transfer-encoding" for k, _ in hs):
        hs.append(("Content-Length", str(len(data))))
    hs.append(("Connection", "close"))
    m = method.encode() if isinstance(method, str) else method
    t = target.encode("latin1") if isinstance(target, str) else target
    head = m + b" " + t + b" " + version.encode() + b"\r\n"
    for k, v in hs:
        head += k.encode("latin1") + b": " + (v.encode("latin1") if isinstance(v, str) else v) + b"\r\n"
    head += extra_raw + b"\r\n"
    return send_raw(port, head + (data if body is not None else b""), timeout)


# ---------------- gateway process mgmt ----------------
class GW:
    def __init__(self, sub, replica, stdout=None, env=None, tag="", port=None):
        self.sub, self.replica = sub, replica
        self.port = port or (BASE + replica)
        self.out_path = f"{OUT}/{sub}_{tag}r{replica}.out"
        self.err_path = f"{OUT}/{sub}_{tag}r{replica}.err"
        e = {"PATH": os.environ["PATH"], "REPLICA_ID": str(replica), "GATEWAY_ADDR": f"127.0.0.1:{self.port}",
             "SEARCH_BACKEND_URL": "http://127.0.0.1:19001", "FILES_BACKEND_URL": "http://127.0.0.1:19002",
             "RESOLVE_BACKEND_URL": "http://127.0.0.1:19003"}
        if env:
            e.update(env)
            for k in [k for k, v in e.items() if v is None]:
                del e[k]
        self.stdout = stdout if stdout is not None else open(self.out_path, "wb")
        self.errf = open(self.err_path, "wb")
        self.proc = subprocess.Popen([SUBS[sub]], env=e, stdout=self.stdout, stderr=self.errf, stdin=subprocess.DEVNULL)
        self.wait_ready()

    def wait_ready(self):
        for _ in range(100):
            if self.proc.poll() is not None:
                return
            try:
                socket.create_connection(("127.0.0.1", self.port), timeout=0.2).close()
                return
            except OSError:
                time.sleep(0.05)

    def alive(self):
        return self.proc.poll() is None

    def rss_hwm_kb(self):
        try:
            for l in open(f"/proc/{self.proc.pid}/status"):
                if l.startswith("VmHWM"):
                    return int(l.split()[1])
        except Exception:
            return None

    def threads(self):
        try:
            for l in open(f"/proc/{self.proc.pid}/status"):
                if l.startswith("Threads"):
                    return int(l.split()[1])
        except Exception:
            return None

    def stop(self, sig=signal.SIGKILL):
        if self.alive():
            self.proc.send_signal(sig)
        try:
            self.proc.wait(timeout=5)
        except Exception:
            self.proc.kill()
        for f in (self.stdout, self.errf):
            try:
                f.close()
            except Exception:
                pass

    def stdout_text(self):
        try:
            return open(self.out_path, "rb").read()
        except Exception:
            return b""


def start_cluster(sub, tag=""):
    return [GW(sub, i, tag=tag) for i in range(4)]


def stop_cluster(gws):
    for g in gws:
        g.stop()


def record(name, passed, obs=None, note="", cat=""):
    RES[name] = {"pass": passed, "obs": obs, "note": note, "cat": cat}


def run_test(fn, *a):
    try:
        fn(*a)
    except Exception as e:
        record(fn.__name__, None, {"exception": repr(e), "tb": traceback.format_exc()[-600:]}, "harness exception")


# ---------------- oracle on fixture records ----------------
SEARCH_URI = re.compile(r"^/v1/search\?q=[A-Za-z0-9+_-]{1,200}$")
FILE_URI = re.compile(r"^/v1/files/[A-Za-z0-9_-]{1,64}$")
HOST_RE = re.compile(r"^(?=.{1,253}$)([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)(\.[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)*$")


def oracle_violations(recs):
    bad = []
    for r in recs:
        if r["backend"] == "search":
            m = re.match(r"^/v1/search\?q=([^&]*)$", r["uri"])
            if not m:
                bad.append(r)
                continue
            from urllib.parse import unquote_plus
            v = unquote_plus(m.group(1))
            if not re.fullmatch(r"[A-Za-z0-9 _-]{1,64}", v) or "%" in m.group(1).replace("%20", ""):
                bad.append(r)
        elif r["backend"] == "files":
            if not FILE_URI.match(r["uri"]):
                bad.append(r)
        else:
            try:
                o = json.loads(r["body"])
                if list(o.keys()) != ["host"] or not HOST_RE.match(o["host"]) or o["host"] != o["host"].lower() or r["uri"] != "/v1/tools/resolve" or r["method"] != "POST":
                    bad.append(r)
            except Exception:
                bad.append(r)
    return bad


def sp(p):
    return BASE + p


# =====================================================================
# FUNCTIONAL
# =====================================================================
def t_functional():
    p = sp(0)
    fx_reset()
    # F1 search canonical + header policy
    r = req(p, "GET", "/v1/search?q=hello+world", headers=[("Accept", "application/json"), ("If-None-Match", '"abc"'),
            ("Authorization", "Bearer SECRETTOKEN"), ("Cookie", "sid=COOKIESECRET"), ("X-Client-ID", "victim"),
            ("X-Forwarded-For", "1.2.3.4"), ("Content-Type", "text/plain"), ("TE", "trailers"), ("Upgrade", "foo"),
            ("Connection", "keep-alive, X-Foo"), ("X-Foo", "bar")])
    L = fx_log()["recs"]
    ok = r.status == 200 and len(L) == 1 and L[0]["uri"] == "/v1/search?q=hello+world"
    hd = L[0]["headers"] if L else {}
    leaked = [k for k in hd if k in ("authorization", "cookie", "x-verified-client-id", "x-client-id", "x-forwarded-for", "x-foo", "te", "upgrade")]
    fwd = [k for k in ("accept", "if-none-match", "content-type") if k in hd]
    record("F1_search_valid_and_header_policy", ok and not leaked and len(fwd) == 3,
           {"status": r.status, "uri": L[0]["uri"] if L else None, "leaked": leaked, "forwarded_required": fwd, "all_headers": sorted(hd)}, cat="func")
    # F2 files canonicalization of %61
    fx_reset()
    r = req(p, "GET", "/v1/files/%61bc_1-2")
    L = fx_log()["recs"]
    record("F2_files_valid_decode_once_canonical", r.status == 200 and len(L) == 1 and L[0]["uri"] == "/v1/files/abc_1-2",
           {"status": r.status, "uri": L[0]["uri"] if L else None}, cat="func")
    # F3 resolve canonical
    fx_reset()
    r = req(p, "POST", "/v1/tools/resolve", headers=[("Content-Type", "application/json; charset=utf-8")], body='{ "host" : "ExAmPlE.CoM" }')
    L = fx_log()["recs"]
    ok = r.status == 200 and len(L) == 1 and L[0]["body"] == '{"host":"example.com"}' and L[0]["method"] == "POST"
    record("F3_resolve_valid_lowercase_canonical", ok, {"status": r.status, "body": L[0]["body"] if L else None,
           "ct": L[0]["headers"].get("content-type") if L else None}, cat="func")
    # F4 response forwarding: status/body/end-to-end hdrs, strip hop-by-hop
    r = req(p, "GET", "/v1/files/e404")
    record("F4a_upstream_404_status_body_preserved", r.status == 404 and r.body == b"fixture-not-found" and r.h("x-custom") == ["v"],
           {"status": r.status, "body": r.body[:50].decode("latin1"), "x-custom": r.h("x-custom")}, cat="func")
    r = req(p, "GET", "/v1/files/hop")
    hop_leak = [k for k, _ in r.headers if k.lower() in ("x-hop", "keep-alive")]
    record("F4b_hop_by_hop_response_headers_stripped", r.status == 200 and not hop_leak and r.h("x-custom") == ["v"] and r.h("set-cookie") == ["a=b"],
           {"status": r.status, "hop_leaked": hop_leak, "x-custom": r.h("x-custom"), "set-cookie": r.h("set-cookie")}, cat="func")
    r = req(p, "GET", "/v1/files/hop2")
    hop2 = [k for k, _ in r.headers if k.lower() in ("x-hop2",)]
    record("F4b2_nominated_hop_header_stripped_without_close_token", r.status == 200 and not hop2 and r.h("x-custom") == ["v"],
           {"status": r.status, "hop_leaked": hop2, "connection_hdr": r.h("connection")}, cat="func")
    r1 = req(p, "GET", "/v1/files/etag", headers=[("If-None-Match", '"v1"')])
    record("F4c_conditional_304_preserved", r1.status == 304, {"status": r1.status}, cat="func")
    r = req(p, "GET", "/v1/files/err500")
    record("F4d_upstream_500_preserved_not_leaked_as_other", r.status in (500, 502), {"status": r.status, "body": r.body[:60].decode("latin1")},
           "spec ambiguous: 'successful upstream response' preserved; non-success may be 502", cat="func")
    # F5 response size
    r = req(p, "GET", "/v1/files/exact", timeout=8)
    record("F5a_exactly_1MiB_response_ok", r.status == 200 and len(r.body) == 1 << 20, {"status": r.status, "len": len(r.body)}, cat="func")
    r = req(p, "GET", "/v1/files/over1", timeout=8)
    record("F5b_1MiB_plus1_content_length_502", r.status == 502 and len(r.body) < 1000, {"status": r.status, "len": len(r.body)}, cat="func")
    r = req(p, "GET", "/v1/files/bigchunk", timeout=8)
    record("F5c_chunked_over_limit_502_no_partial_success", r.status == 502 and len(r.body) < 1000, {"status": r.status, "len": len(r.body)}, cat="func")
    r = req(p, "GET", "/v1/files/exactchunk", timeout=8)
    record("F5d_chunked_exactly_1MiB_ok", r.status == 200 and len(r.body) == 1 << 20, {"status": r.status, "len": len(r.body)}, cat="func")
    r = req(p, "GET", "/v1/files/over1chunk", timeout=8)
    record("F5e_chunked_1MiB_plus1_502", r.status == 502 and len(r.body) < 1000, {"status": r.status, "len": len(r.body)}, cat="func")
    # F6 upstream failures
    t0 = time.time()
    r = req(p, "GET", "/v1/search?q=slow", timeout=8)
    dt = time.time() - t0
    record("F6a_upstream_timeout_504_at_2s", r.status == 504 and 1.8 <= dt <= 2.6, {"status": r.status, "secs": round(dt, 2)}, cat="func")
    r = req(p, "GET", "/v1/files/reset")
    record("F6b_upstream_reset_502", r.status == 502, {"status": r.status}, cat="func")
    leakwords = ["127.0.0.1", "dial", "EOF", "goroutine", ".go:", "panic", "refused", "boom", "secret"]
    bodies = []
    for tgt in ("/v1/files/reset", "/v1/search?q=slow", "/v1/files/err500", "/v1/files/over1"):
        if tgt == "/v1/search?q=slow":
            continue
        rr = req(p, "GET", tgt, timeout=8)
        bodies.append((rr.status, rr.body.decode("latin1")))
    leaks = [(s, b[:80]) for s, b in bodies if s in (502, 504) and any(w.lower() in b.lower() for w in leakwords)]
    record("F6c_error_bodies_do_not_leak_diagnostics", not leaks, {"leaks": leaks, "samples": bodies[:3]}, cat="func")
    # F7 cancellation propagation
    fx_reset()
    s = socket.create_connection(("127.0.0.1", p), timeout=3)
    s.sendall(f"GET /v1/search?q=slow HTTP/1.1\r\nHost: x\r\nX-Verified-Client-ID: {uid()}\r\n\r\n".encode())
    time.sleep(0.4)
    s.close()
    time.sleep(1.0)
    st = fx_stats()
    record("F7_client_disconnect_cancels_upstream", st["cancelled"] >= 1, {"fixture_cancelled": st["cancelled"]}, cat="func")
    # F8 status codes
    codes = {}
    codes["404_unknown"] = req(p, "GET", "/nope").status
    codes["405_post_search"] = req(p, "POST", "/v1/search?q=a", body="x").status
    codes["405_get_resolve"] = req(p, "GET", "/v1/tools/resolve").status
    codes["405_delete_files"] = req(p, "DELETE", "/v1/files/abc").status
    codes["401_no_ident"] = req(p, "GET", "/v1/search?q=a", ident=None).status
    codes["401_bad_ident_space"] = req(p, "GET", "/v1/search?q=a", ident="a b").status
    codes["401_bad_ident_129"] = req(p, "GET", "/v1/search?q=a", ident="a" * 129).status
    codes["200_ident_128"] = req(p, "GET", "/v1/search?q=a", ident="a" * 128).status
    codes["401_dup_ident"] = req(p, "GET", "/v1/search?q=a", ident=[uid(), uid()]).status
    codes["401_empty_ident"] = req(p, "GET", "/v1/search?q=a", ident="").status
    codes["400_search_empty"] = req(p, "GET", "/v1/search?q=").status
    exp = {"404_unknown": 404, "405_post_search": 405, "405_get_resolve": 405, "405_delete_files": 405, "401_no_ident": 401,
           "401_bad_ident_space": 401, "401_bad_ident_129": 401, "200_ident_128": 200, "401_dup_ident": 401, "401_empty_ident": 401, "400_search_empty": 400}
    bad = {k: (codes[k], exp[k]) for k in exp if codes[k] != exp[k]}
    record("F8_status_code_matrix", not bad, {"mismatches(obs,exp)": bad, "all": codes}, cat="func")
    # F9 health & metrics (no identity supplied: ingress only guarantees injected identity, but probes may omit it)
    r = req(p, "GET", "/healthz", ident=None)
    record("F9a_healthz_200_without_identity", r.status == 200, {"status": r.status}, "readiness probes often lack the identity header", cat="func")
    r = req(p, "GET", "/healthz")
    record("F9b_healthz_200_with_identity", r.status == 200, {"status": r.status}, cat="func")
    r = req(p, "GET", "/_internal/metrics", ident=None)
    mj = None
    try:
        mj = json.loads(r.body)
    except Exception:
        pass
    record("F9c_metrics_200_without_identity", r.status == 200 and mj is not None, {"status": r.status, "json": mj}, cat="func")
    r = req(p, "POST", "/healthz", body="")
    record("F9d_healthz_post_405", r.status == 405, {"status": r.status}, cat="func")
    # F10 query on files/resolve (spec silent)
    fx_reset()
    r = req(p, "GET", "/v1/files/abc?x=1")
    L = fx_log()["recs"]
    record("F10a_files_with_query_behavior(info)", None, {"status": r.status, "forwarded_uri": L[0]["uri"] if L else None}, "spec silent on query for files", cat="info")
    fx_reset()
    r = req(p, "POST", "/v1/tools/resolve?x=1", headers=[("Content-Type", "application/json")], body='{"host":"a.com"}')
    L = fx_log()["recs"]
    record("F10b_resolve_with_query_behavior(info)", None, {"status": r.status, "forwarded_uri": L[0]["uri"] if L else None}, "spec silent", cat="info")


# =====================================================================
# SECURITY corpora
# =====================================================================
SEARCH_BAD = {
    "dup_q": "?q=a&q=b", "extra_param": "?q=a&x=1", "extra_param_first": "?x=1&q=a", "bad_escape_pct": "?q=%", "bad_escape_zz": "?q=%zz",
    "bad_escape_trunc": "?q=a%2", "empty": "?q=", "no_q": "?x=1", "no_value": "?q", "no_query": "", "upper_Q": "?Q=a",
    "len65": "?q=" + "a" * 65, "sqli_quote": "?q=%27+OR+1%3D1--", "sqli_raw": "?q=' OR 1=1--", "sqli_union": "?q=a+UNION+SELECT+*",
    "semicolon": "?q=a;b", "semicolon_param": "?q=a;q=b", "encoded_amp": "?q=a%26q%3Db", "encoded_eq": "?q=a%3Db", "double_enc": "?q=%2527",
    "double_enc_pct": "?q=%252e", "plus_enc": "?q=a%2Bb", "nul": "?q=a%00b", "nl": "?q=a%0Ab", "cr": "?q=a%0Db", "tab": "?q=a%09b",
    "utf8": "?q=%C3%A9", "overlong": "?q=%C0%AE", "rtl": "?q=%E2%80%AE", "slash": "?q=a%2Fb", "dotdot": "?q=..", "bracket": "?q[]=a",
    "trailing_amp": "?q=a&", "leading_amp": "?&q=a", "dup_empty": "?q=a&q=", "hash_enc": "?q=a%23b", "pct_pct": "?q=%%41",
    "wide_char": "?q=%EF%BC%A1", "backslash": "?q=a%5Cb", "semicolon_enc": "?q=a%3Bb", "nul_raw": "?q=a%00",
}
SEARCH_OK = {"a": ("?q=a", "?q=a"), "plus_space": ("?q=a+b", "?q=a+b"), "pct20": ("?q=a%20b", "?q=a+b"), "mixed": ("?q=A-z_9", "?q=A-z_9"),
             "len64": ("?q=" + "a" * 64, "?q=" + "a" * 64), "pct_letter": ("?q=%61", "?q=a"), "pct_upper_hex": ("?q=hel%6Co", "?q=hello"),
             "space_only_in_middle": ("?q=a+++b", "?q=a+++b"), "single_space": ("?q=%20", "?q=+")}

FILE_BAD = {
    "dotdot": "/v1/files/..", "dot": "/v1/files/.", "enc_dotdot": "/v1/files/%2e%2e", "enc_dotdot_upper": "/v1/files/%2E%2E",
    "enc_dotdot_slash": "/v1/files/%2e%2e%2f", "enc_slash": "/v1/files/a%2fb", "enc_slash_upper": "/v1/files/a%2Fb", "enc_backslash": "/v1/files/a%5cb",
    "raw_backslash": "/v1/files/a\\b", "double_enc_dot": "/v1/files/%252e%252e", "double_enc_slash": "/v1/files/a%252fb", "double_enc_pct": "/v1/files/%2541",
    "bad_escape": "/v1/files/%", "bad_escape_zz": "/v1/files/%zz", "bad_escape_trunc": "/v1/files/a%2", "extra_segment": "/v1/files/a/b",
    "dotdot_segment": "/v1/files/a/../b", "empty": "/v1/files/", "double_slash": "/v1/files//x", "nul": "/v1/files/a%00b", "space": "/v1/files/a%20b",
    "len65": "/v1/files/" + "a" * 65, "semicolon": "/v1/files/a;b", "enc_semicolon": "/v1/files/a%3Bb", "dot_in_name": "/v1/files/a.txt",
    "enc_dot_in_name": "/v1/files/a%2etxt", "utf8": "/v1/files/%C3%A9", "overlong_slash": "/v1/files/%C0%AF", "overlong_dot": "/v1/files/%C0%AE%C0%AE",
    "unicode_slash": "/v1/files/a%E2%88%95b", "tilde": "/v1/files/~root", "colon": "/v1/files/c:", "nl": "/v1/files/a%0Ab", "star": "/v1/files/*",
    "encoded_enc": "/v1/files/%2e%2e%252f", "mixed_dotdot_enc": "/v1/files/.%2e", "mixed_dotdot_enc2": "/v1/files/%2e.", "path_param": "/v1/files/a;/../b",
    "pre_encoded_prefix": "/v1/files%2Fabc", "pre_enc_v1": "/v1%2Ffiles/abc", "case_prefix": "/V1/files/abc", "trailing_slash": "/v1/files/abc/",
}
FILE_OK = {"plain": ("/v1/files/abc", "/v1/files/abc"), "pct_letter": ("/v1/files/%61bc", "/v1/files/abc"), "dash_us": ("/v1/files/a-b_C9", "/v1/files/a-b_C9"),
           "len64": ("/v1/files/" + "a" * 64, "/v1/files/" + "a" * 64), "enc_dash": ("/v1/files/a%2Db", "/v1/files/a-b"), "enc_us": ("/v1/files/a%5Fb", "/v1/files/a_b")}

RESOLVE_CT = [("Content-Type", "application/json")]
RESOLVE_BAD = {
    "dup_key": '{"host":"a.com","host":"b.com"}', "dup_key_escaped": '{"host":"a.com","h\\u006fst":"b.com"}', "dup_key_escaped_first": '{"h\\u006fst":"a.com","host":"b.com"}',
    "dup_key_both_escaped": '{"h\\u006fst":"a.com","\\u0068ost":"b.com"}', "extra_field": '{"host":"a.com","x":1}', "extra_first": '{"x":1,"host":"a.com"}',
    "empty_obj": "{}", "array": '["a.com"]', "string": '"a.com"', "number": "1", "null": "null", "trailing_obj": '{"host":"a.com"}{}', "trailing_garbage": '{"host":"a.com"}x',
    "trailing_value": '{"host":"a.com"} 1', "trailing_comma": '{"host":"a.com",}', "nan": '{"host":NaN}', "infinity": '{"host":Infinity}', "single_quote": "{'host':'a.com'}",
    "unquoted_key": '{host:"a.com"}', "comment": '{"host":"a.com"/*x*/}', "num_host": '{"host":123}', "null_host": '{"host":null}', "arr_host": '{"host":["a.com"]}',
    "obj_host": '{"host":{"a":1}}', "bool_host": '{"host":true}', "empty_host": '{"host":""}', "trailing_dot": '{"host":"a.com."}', "lead_hyphen": '{"host":"-a.com"}',
    "trail_hyphen": '{"host":"a-.com"}', "label64": '{"host":"' + "a" * 64 + '.com"}', "host254": '{"host":"' + ".".join(["a" * 63] * 3 + ["a" * 62]) + '"}',
    "underscore": '{"host":"a_b.com"}', "space": '{"host":"a b.com"}', "semicolon_cmd": '{"host":"a.com; id"}', "dollar_cmd": '{"host":"$(id).com"}', "backtick": '{"host":"`id`.com"}',
    "pipe": '{"host":"a.com|id"}', "amp": '{"host":"a.com&&id"}', "nl": '{"host":"a.com\\nid"}', "nul_esc": '{"host":"a.com\\u0000"}', "unicode": '{"host":"\\u00e9.com"}',
    "unicode_raw_utf8": '{"host":"é.com"}', "double_dot": '{"host":"a..com"}', "leading_dot": '{"host":".a.com"}', "lone_surrogate": '{"host":"\\ud800.com"}',
    "slash": '{"host":"a.com/x"}', "colon_port": '{"host":"a.com:80"}', "at": '{"host":"u@a.com"}', "bom": "\ufeff" + '{"host":"a.com"}', "empty_body": "", "whitespace_only": "   ",
    "nested_deep": "[" * 5000, "dup_nested": '{"host":"a.com","host":{"x":1}}', "ctrl_in_str": '{"host":"a.com\x01"}', "unterminated": '{"host":"a.com"', "ws_inside_host": '{"host":" a.com"}',
    "escaped_dot_ok_check": '{"host":"a\\u002ecom\\u0000"}',
}
RESOLVE_ENCODED_BAD = {"invalid_utf8_value": b'{"host":"a\xff.com"}', "invalid_utf8_key": b'{"h\xffst":"a.com"}', "invalid_utf8_trailing": b'{"host":"a.com"}\xff',
                       "invalid_utf8_overlong": b'{"host":"a\xc0\xaf.com"}', "latin1_e": b'{"host":"\xe9.com"}', "truncated_mb": b'{"host":"a\xe2\x82.com"}'}
RESOLVE_OK = {"basic": ('{"host":"example.com"}', "example.com"), "upper": ('{"host":"EXAMPLE.COM"}', "example.com"), "escaped_key": ('{"h\\u006fst":"a.com"}', "a.com"),
              "single_label": ('{"host":"localhost"}', "localhost"), "hyphen_mid": ('{"host":"a-b.c-d.com"}', "a-b.c-d.com"), "label63": ('{"host":"' + "a" * 63 + '.com"}', "a" * 63 + ".com"),
              "host253": ('{"host":"' + ".".join(["a" * 63] * 3 + ["a" * 61]) + '"}', ".".join(["a" * 63] * 3 + ["a" * 61])), "ws_around": ('  \n{"host" :\t"a.com"}  \n', "a.com"),
              "escaped_val": ('{"host":"a\\u002ecom"}', "a.com"), "digits": ('{"host":"123.456"}', "123.456")}
RESOLVE_CT_BAD = {"text_plain": "text/plain", "missing": None, "latin1": "application/json; charset=latin1", "boundary": "application/json; boundary=x",
                  "form": "application/x-www-form-urlencoded", "json_suffix": "application/vnd.api+json", "garbage": "application/json;;", "two_params": "application/json; charset=utf-8; x=y",
                  "utf16": "application/json; charset=utf-16"}
RESOLVE_CT_OK = {"plain": "application/json", "charset": "application/json; charset=utf-8", "charset_upper": "application/json;charset=UTF-8", "mime_case": "Application/JSON"}


def t_security():
    p = sp(1)
    fx_reset()
    bad_fwd, bad_status, details = [], [], {}
    # ---- SEARCH
    for name, q in SEARCH_BAD.items():
        fx_reset()
        r = req(p, "GET", "/v1/search" + q)
        n = fx_stats()["counts"][0]
        details[f"search:{name}"] = (r.status, n)
        if n:
            bad_fwd.append(("search", name, q[:60]))
        elif r.status != 400:
            bad_status.append(("search", name, r.status))
    fp, ok_fail = [], []
    for name, (q, exp) in SEARCH_OK.items():
        fx_reset()
        r = req(p, "GET", "/v1/search" + q)
        L = fx_log()["recs"]
        if not (r.status == 200 and len(L) == 1 and L[0]["uri"] == "/v1/search" + exp):
            ok_fail.append(("search", name, r.status, L[0]["uri"] if L else None))
    record("S1_search_invalid_never_forwarded", not bad_fwd, {"forwarded_invalid": bad_fwd, "n_cases": len(SEARCH_BAD)}, cat="sec")
    record("S1b_search_invalid_status_400", not bad_status, {"non400": bad_status}, cat="sec")
    record("S1c_search_valid_accepted_canonical", not ok_fail, {"fail": ok_fail}, cat="sec")
    # ---- FILES
    bad_fwd, bad_status, ok_fail = [], [], []
    for name, t in FILE_BAD.items():
        fx_reset()
        r = req(p, "GET", t)
        n = fx_stats()["counts"][1]
        details[f"files:{name}"] = (r.status, n)
        if n:
            bad_fwd.append(("files", name, t[:60], fx_log()["recs"][0]["uri"]))
        elif r.status not in (400, 404):
            bad_status.append(("files", name, r.status))
    for name, (t, exp) in FILE_OK.items():
        fx_reset()
        r = req(p, "GET", t)
        L = fx_log()["recs"]
        if not (r.status == 200 and len(L) == 1 and L[0]["uri"] == exp):
            ok_fail.append((name, r.status, L[0]["uri"] if L else None))
    record("S2_files_invalid_never_forwarded", not bad_fwd, {"forwarded_invalid": bad_fwd, "n_cases": len(FILE_BAD)}, cat="sec")
    record("S2b_files_invalid_status_400_or_404", not bad_status, {"other": bad_status}, cat="sec")
    record("S2c_files_valid_accepted_canonical", not ok_fail, {"fail": ok_fail}, cat="sec")
    # status detail for the ones that are not plain 400
    record("S2d_files_status_detail(info)", None, {k: v for k, v in details.items() if k.startswith("files:") and v[0] != 400}, cat="info")
    # ---- RESOLVE
    bad_fwd, bad_status, ok_fail = [], [], []
    for name, body in RESOLVE_BAD.items():
        fx_reset()
        b = body.encode("utf-8")
        r = req(p, "POST", "/v1/tools/resolve", headers=RESOLVE_CT, body=b)
        n = fx_stats()["counts"][2]
        details[f"resolve:{name}"] = (r.status, n)
        if n:
            bad_fwd.append(("resolve", name, fx_log()["recs"][0]["body"][:80]))
        elif r.status != 400:
            bad_status.append(("resolve", name, r.status))
    for name, b in RESOLVE_ENCODED_BAD.items():
        fx_reset()
        r = req(p, "POST", "/v1/tools/resolve", headers=RESOLVE_CT, body=b)
        n = fx_stats()["counts"][2]
        if n:
            bad_fwd.append(("resolve", name, fx_log()["recs"][0]["body"][:80]))
        elif r.status != 400:
            bad_status.append(("resolve", name, r.status))
    for name, ct in RESOLVE_CT_BAD.items():
        fx_reset()
        hs = [("Content-Type", ct)] if ct is not None else []
        r = req(p, "POST", "/v1/tools/resolve", headers=hs, body='{"host":"a.com"}')
        n = fx_stats()["counts"][2]
        if n:
            bad_fwd.append(("resolve-ct", name, ct))
        elif r.status != 400 and r.status != 415:
            bad_status.append(("resolve-ct", name, r.status))
    fx_reset()
    r = req(p, "POST", "/v1/tools/resolve", headers=RESOLVE_CT + RESOLVE_CT, body='{"host":"a.com"}')
    if fx_stats()["counts"][2]:
        bad_fwd.append(("resolve-ct", "two_content_type_headers", ""))
    for name, (body, exp) in RESOLVE_OK.items():
        fx_reset()
        r = req(p, "POST", "/v1/tools/resolve", headers=RESOLVE_CT, body=body.encode())
        L = fx_log()["recs"]
        if not (r.status == 200 and len(L) == 1 and L[0]["body"] == json.dumps({"host": exp}, separators=(",", ":"))):
            ok_fail.append((name, r.status, L[0]["body"][:60] if L else None))
    for name, ct in RESOLVE_CT_OK.items():
        fx_reset()
        r = req(p, "POST", "/v1/tools/resolve", headers=[("Content-Type", ct)], body='{"host":"a.com"}')
        if r.status != 200:
            ok_fail.append(("ct:" + name, r.status, None))
    record("S3_resolve_invalid_never_forwarded", not bad_fwd, {"forwarded_invalid": bad_fwd, "n_cases": len(RESOLVE_BAD) + len(RESOLVE_ENCODED_BAD) + len(RESOLVE_CT_BAD) + 1}, cat="sec")
    record("S3b_resolve_invalid_status_400", not bad_status, {"non400": bad_status}, cat="sec")
    record("S3c_resolve_valid_accepted_canonical", not ok_fail, {"fail": ok_fail}, cat="sec")
    # ---- global oracle over everything the backends ever saw is checked implicitly (fx_reset between); run explicit sweep:
    fx_reset()
    for name, q in list(SEARCH_BAD.items())[:20]:
        req(p, "GET", "/v1/search" + q)
    for name, t in list(FILE_BAD.items())[:20]:
        req(p, "GET", t)
    viol = oracle_violations(fx_log()["recs"])
    record("S4_oracle_no_violating_backend_request", not viol, {"violations": viol[:3]}, cat="sec")


def t_identity():
    p = sp(2)
    # identity spoofing: client-controlled header alternatives must not affect quota identity
    ident = uid("spoof")
    codes = []
    for i in range(7):
        r = req(p, "GET", "/v1/search?q=a", ident=ident, headers=[("X-Client-ID", f"other{i}"), ("X-Forwarded-For", f"9.9.9.{i}"), ("X-User", f"u{i}"), ("X-Verified-Client-Id", f"zz{i}x")])
        codes.append(r.status)
    # case-variant duplicate header (Go canonicalizes -> two values -> 401 expected) is the dup test; here we show only first-5-then-429 pattern
    record("I1_only_verified_identity_controls_quota", codes[:5] == [200] * 5 and codes[5:] in ([429, 429],), {"codes": codes}, "case-variant duplicate X-Verified-Client-Id yields a 2-value header -> 401 expected", cat="sec")
    # I1 above sends a case-variant duplicate; re-run without it for a clean quota check
    ident = uid("spoof")
    codes = []
    for i in range(7):
        r = req(p, "GET", "/v1/search?q=a", ident=ident, headers=[("X-Client-ID", f"other{i}"), ("X-Forwarded-For", f"9.9.9.{i}"), ("X-User", f"u{i}")])
        codes.append(r.status)
    record("I2_other_identity_headers_ignored_for_quota", codes == [200] * 5 + [429] * 2, {"codes": codes}, cat="sec")
    # duplicate verified header with different values must not be trusted
    fx_reset()
    r = req(p, "GET", "/v1/search?q=a", ident=[uid("d"), uid("d")])
    record("I3_duplicate_verified_header_rejected_not_forwarded", r.status == 401 and fx_stats()["counts"][0] == 0, {"status": r.status}, cat="sec")
    r = req(p, "GET", "/v1/search?q=a", ident="a,b")
    r2 = req(p, "GET", "/v1/search?q=a", ident="a\tb")
    r3 = req(p, "GET", "/v1/search?q=a", ident="é")
    record("I4_malformed_identity_values_401", r.status == 401 and r2.status == 401 and r3.status in (401, 400), {"comma": r.status, "tab": r2.status, "latin1": r3.status}, cat="sec")


# =====================================================================
# HTTP boundary
# =====================================================================
def many_headers(n, name_prefix="X-H", val="v"):
    return [(f"{name_prefix}{i}", val) for i in range(n)]


def t_http_boundary():
    p = sp(3)
    obs = {}
    # header field counts (Host + X-Verified-Client-ID + N extras (+Connection auto) )
    # the request builder adds Host, X-Verified-Client-ID, Connection => 3 base fields
    for extra, label in ((60, "total63"), (61, "total64"), (62, "total65"), (70, "total73"), (200, "total203")):
        r = req(p, "GET", "/v1/search?q=a", headers=many_headers(extra))
        obs[f"fields_{label}"] = r.status
    r = req(p, "GET", "/v1/search?q=a", headers=[("X-R", "1")] * 70)
    obs["repeated_same_name_x70"] = r.status
    record("H1_header_count_limit", obs["fields_total63"] == 200 and obs["fields_total64"] == 200 and obs["fields_total65"] == 413 and obs["fields_total73"] == 413 and obs["repeated_same_name_x70"] == 413,
           obs, "64 fields allowed (Host,Connection,identity counted); 65+ -> 413", cat="http")
    # aggregate header bytes (wire size ~= 85 + n*(len(name)+vl+4))
    ob = {}
    cases = [("15.3KB", 15, 1000), ("16.3KB", 16, 1000), ("17.3KB", 17, 1000), ("25KB", 25, 1000), ("44KB", 11, 4000), ("100KB", 25, 4000), ("140KB", 35, 4000), ("200KB", 50, 4000)]
    for label, n, vl in cases:
        hs = [(f"X-Big{i:02d}", "a" * vl) for i in range(n)]
        ob[label] = req(p, "GET", "/v1/search?q=a", headers=hs, timeout=6).status
    big = ("17.3KB", "25KB", "44KB", "100KB", "140KB", "200KB")
    record("H2_aggregate_header_bytes_limit", ob["15.3KB"] == 200 and ob["16.3KB"] == 200 and all(ob[k] == 413 for k in big),
           ob, "expect 413 beyond 16 KiB; 431 from net/http itself = wrong status and no log event", cat="http")
    # target size
    ot = {}
    ot["8192_target"] = req(p, "GET", "/" + "a" * 8191).status
    ot["8193_target"] = req(p, "GET", "/" + "a" * 8192).status
    ot["9000_target"] = req(p, "GET", "/" + "a" * 9000).status
    ot["20000_target"] = req(p, "GET", "/" + "a" * 20000).status
    ot["9000_query_search"] = req(p, "GET", "/v1/search?q=" + "a" * 9000).status
    record("H3_target_length_limit", ot["8192_target"] == 404 and ot["8193_target"] == 413 and ot["9000_target"] == 413 and ot["9000_query_search"] == 413, ot, cat="http")
    # body size
    ob = {}
    pad = lambda n: b'{"host":"a.com"}' + b" " * (n - 16)
    ob["body_65536"] = req(p, "POST", "/v1/tools/resolve", headers=RESOLVE_CT, body=pad(65536)).status
    ob["body_65537"] = req(p, "POST", "/v1/tools/resolve", headers=RESOLVE_CT, body=pad(65537)).status
    ob["body_200000"] = req(p, "POST", "/v1/tools/resolve", headers=RESOLVE_CT, body=pad(200000)).status
    chunk = lambda n: (b"%x\r\n" % n) + pad(n) + b"\r\n0\r\n\r\n"
    ob["chunked_65537"] = req(p, "POST", "/v1/tools/resolve", headers=RESOLVE_CT + [("Transfer-Encoding", "chunked")], body=chunk(65537)).status
    ob["chunked_65536"] = req(p, "POST", "/v1/tools/resolve", headers=RESOLVE_CT + [("Transfer-Encoding", "chunked")], body=chunk(65536)).status
    ob["search_get_body_70000"] = req(p, "GET", "/v1/search?q=a", body=b"x" * 70000).status
    record("H4_body_limit", ob["body_65536"] == 200 and ob["body_65537"] == 413 and ob["body_200000"] == 413 and ob["chunked_65537"] == 413 and ob["chunked_65536"] == 200, ob, cat="http")
    # framing ambiguity: gateway re-originates upstream requests, so only validated values can reach a backend.
    fx_reset()
    cl_te = (f"POST /v1/tools/resolve HTTP/1.1\r\nHost: x\r\nX-Verified-Client-ID: {uid()}\r\nContent-Type: application/json\r\nContent-Length: 4\r\nTransfer-Encoding: chunked\r\n\r\n"
             f"0\r\n\r\nGET /v1/files/%2e%2e HTTP/1.1\r\nHost: x\r\nX-Verified-Client-ID: {uid()}\r\n\r\n").encode()
    r = send_raw(p, cl_te, timeout=3)
    te_te = (f"POST /v1/tools/resolve HTTP/1.1\r\nHost: x\r\nX-Verified-Client-ID: {uid()}\r\nContent-Type: application/json\r\nTransfer-Encoding: chunked\r\nTransfer-Encoding: identity\r\n\r\n0\r\n\r\n").encode()
    r2 = send_raw(p, te_te, timeout=3)
    dup_cl = (f"POST /v1/tools/resolve HTTP/1.1\r\nHost: x\r\nX-Verified-Client-ID: {uid()}\r\nContent-Type: application/json\r\nContent-Length: 16\r\nContent-Length: 17\r\n\r\n" + '{"host":"a.com"}').encode()
    r3 = send_raw(p, dup_cl, timeout=3)
    obsfold = (f"GET /v1/search?q=a HTTP/1.1\r\nHost: x\r\nX-Verified-Client-ID: {uid()}\r\nX-A: b\r\n  X-Verified-Client-ID: evil\r\n\r\n").encode()
    r4 = send_raw(p, obsfold, timeout=3)
    bare_lf = (f"GET /v1/search?q=a HTTP/1.1\nHost: x\nX-Verified-Client-ID: {uid()}\n\n").encode()
    r5 = send_raw(p, bare_lf, timeout=3)
    sp_colon = (f"GET /v1/search?q=a HTTP/1.1\r\nHost: x\r\nX-Verified-Client-ID : {uid()}\r\n\r\n").encode()
    r6 = send_raw(p, sp_colon, timeout=3)
    L = fx_log()["recs"]
    viol = oracle_violations(L)
    files_seen = [x["uri"] for x in L if x["backend"] == "files"]
    record("H5_framing_ambiguity_never_forwards_invalid", not viol and not files_seen,
           {"cl_te": r.status, "te_te": r2.status, "dup_cl": r3.status, "obs_fold": r4.status, "bare_lf": r5.status, "space_before_colon": r6.status,
            "backend_requests": [(x["backend"], x["uri"]) for x in L], "oracle_violations": len(viol), "invalid_pipelined_file_forwarded": files_seen}, cat="sec")
    # absolute-form / odd targets
    fx_reset()
    r = send_raw(p, f"GET http://evil.example/v1/search?q=a HTTP/1.1\r\nHost: x\r\nX-Verified-Client-ID: {uid()}\r\nConnection: close\r\n\r\n".encode(), timeout=3)
    r2 = send_raw(p, f"GET //v1/search?q=a HTTP/1.1\r\nHost: x\r\nX-Verified-Client-ID: {uid()}\r\nConnection: close\r\n\r\n".encode(), timeout=3)
    r3 = send_raw(p, f"GET /v1/search/?q=a HTTP/1.1\r\nHost: x\r\nX-Verified-Client-ID: {uid()}\r\nConnection: close\r\n\r\n".encode(), timeout=3)
    r4 = send_raw(p, f"GET /./v1/search?q=a HTTP/1.1\r\nHost: x\r\nX-Verified-Client-ID: {uid()}\r\nConnection: close\r\n\r\n".encode(), timeout=3)
    r5 = send_raw(p, f"GET /v1/search?q=a#frag HTTP/1.1\r\nHost: x\r\nX-Verified-Client-ID: {uid()}\r\nConnection: close\r\n\r\n".encode(), timeout=3)
    L = fx_log()["recs"]
    record("H6_odd_targets_safe", all(x["uri"] in ("/v1/search?q=a",) for x in L) and not oracle_violations(L),
           {"absolute_form": r.status, "double_slash": r2.status, "trailing_slash": r3.status, "dot_segment": r4.status, "fragment": r5.status, "forwarded": [x["uri"] for x in L]}, cat="sec")
    # OPTIONS * desync probe: bypass of header limits via scanner/handler mismatch
    s = socket.create_connection(("127.0.0.1", p), timeout=5)
    ident = uid()
    s.sendall(b"OPTIONS * HTTP/1.1\r\nHost: x\r\n\r\n")
    a = recv_all(s, 0.6)
    hs = "".join(f"X-H{i}: v\r\n" for i in range(80))
    s.sendall(f"GET /v1/search?q=a HTTP/1.1\r\nHost: x\r\nX-Verified-Client-ID: {ident}\r\n{hs}\r\n".encode())
    b = recv_all(s, 1.0)
    s.close()
    ra, rb = parse_resp(a), parse_resp(b)
    record("H7_options_star_then_80_headers_same_conn", rb.status == 413, {"options_star": ra.status, "then_80_header_request": rb.status},
           "413 expected (limit 64); 200 means header-count limit bypassed via parser/handler desync", cat="http")
    # pipelining sanity
    s = socket.create_connection(("127.0.0.1", p), timeout=5)
    s.sendall((f"GET /v1/search?q=a HTTP/1.1\r\nHost: x\r\nX-Verified-Client-ID: {uid()}\r\n\r\n" * 3).encode())
    raw = recv_all(s, 1.0)
    s.close()
    record("H8_pipelined_3_requests", raw.count(b"HTTP/1.1 200") == 3, {"count_200": raw.count(b"HTTP/1.1 200")}, cat="http")


# =====================================================================
# RATE LIMITING
# =====================================================================
def tool(*args, timeout=120):
    out = subprocess.run([f"{H}/tool.bin", *map(str, args)], capture_output=True, text=True, timeout=timeout)
    return json.loads(out.stdout.strip().splitlines()[-1])


def t_rate_basic():
    p = sp(0)
    ident = uid("rl")
    t0 = time.time()
    codes, ra = [], []
    for i in range(8):
        r = req(p, "GET", "/v1/search?q=a", ident=ident)
        codes.append(r.status)
        if r.status == 429:
            ra.append(r.h("retry-after"))
    el = time.time() - t0
    ok = codes[:5] == [200] * 5 and all(c == 429 for c in codes[5:])
    ra_ok = all(len(x) == 1 and x[0].isdigit() and 1 <= int(x[0]) <= 3 for x in ra)
    record("R1_bucket_capacity_5_then_429_retry_after", ok and ra_ok, {"codes": codes, "retry_after": ra, "elapsed": round(el, 2)}, cat="rate")
    time.sleep(max(0, 2.15 - (time.time() - t0 - el)) + 0.0)
    time.sleep(2.2)
    codes2 = [req(p, "GET", "/v1/search?q=a", ident=ident).status for _ in range(3)]
    n200 = codes2.count(200)
    record("R2_refill_half_token_per_sec", n200 == 2 or n200 == 1 and False, {"codes_after_~4.4s": codes2, "expected": "~2 tokens refilled -> [200,200,429]"}, cat="rate")
    # isolation
    a, b = uid("iso"), uid("iso")
    for _ in range(6):
        req(p, "GET", "/v1/search?q=a", ident=a)
    ra_ = req(p, "GET", "/v1/search?q=a", ident=a).status
    rb_ = req(p, "GET", "/v1/search?q=a", ident=b).status
    record("R3_identity_isolation", ra_ == 429 and rb_ == 200, {"exhausted_A": ra_, "fresh_B": rb_}, cat="rate")
    # invalid input does not consume
    c = uid("inv")
    inv = [req(p, "GET", "/v1/search?q=%", ident=c).status for _ in range(10)]
    inv += [req(p, "GET", "/nope", ident=c).status for _ in range(3)]
    inv += [req(p, "POST", "/v1/search?q=a", ident=c, body="").status for _ in range(3)]
    ok5 = [req(p, "GET", "/v1/search?q=a", ident=c).status for _ in range(6)]
    record("R4_invalid_requests_dont_consume_tokens", ok5 == [200] * 5 + [429], {"invalid_statuses": sorted(set(inv)), "then": ok5}, cat="rate")
    # concurrent atomicity
    for trial in range(3):
        c = uid("atom")
        res = tool("burst", f"127.0.0.1:{p}", c, 300, 100)
    c = uid("atom")
    res = tool("burst", f"127.0.0.1:{p}", c, 400, 100)
    n200 = res["statuses"].get("200", 0)
    record("R5_concurrent_burst_exactly_5_admitted", n200 in (5, 6) and n200 == 5, {"statuses": res["statuses"], "elapsed": round(res["elapsed"], 2)}, "400 concurrent requests, one identity, one replica", cat="rate")


def t_rate_cluster():
    # even-traffic envelope + utilization across 4 replicas
    ident = uid("env")
    ports = [sp(i) for i in range(4)]
    admitted = 0
    log = []
    stop = time.time() + 40.0
    t_first = time.time()
    # initial simultaneous burst: 12 reqs per replica
    def hit(port):
        r = req(port, "GET", "/v1/search?q=a", ident=ident, timeout=5)
        return r.status
    ths, out = [], []
    lock = threading.Lock()
    def w(port):
        s = hit(port)
        with lock:
            out.append(s)
    for port in ports:
        for _ in range(12):
            ths.append(threading.Thread(target=w, args=(port,)))
    for t in ths:
        t.start()
    for t in ths:
        t.join()
    burst_adm = out.count(200)
    admitted = burst_adm
    # sustained round-robin at ~16 req/s total
    i = 0
    nxt = time.time()
    last_done = time.time()
    while time.time() < stop:
        r = req(ports[i % 4], "GET", "/v1/search?q=a", ident=ident, timeout=5)
        if r.status == 200:
            admitted += 1
        last_done = time.time()
        i += 1
        nxt += 0.0625
        d = nxt - time.time()
        if d > 0:
            time.sleep(d)
    T = last_done - t_first
    bound = 20 + 2 * T
    record("R6_even_traffic_envelope_admitted_le_20_plus_2T", admitted <= bound + 0.5, {"admitted": admitted, "T": round(T, 2), "bound": round(bound, 2), "burst_admitted": burst_adm}, cat="rate")
    util = admitted / bound
    ideal = 4 * math.floor(5 + 0.5 * T)
    record("R7_even_traffic_utilization_ge_95pct", util >= 0.95, {"admitted": admitted, "bound": round(bound, 2), "utilization": round(util, 4),
           "integer_token_ideal": ideal, "vs_ideal": round(admitted / ideal, 4)}, cat="rate")
    # uneven: all to replica 2 for 12s at 10 rps
    ident = uid("uneven")
    adm = 0
    t0 = time.time()
    nxt = t0
    last = t0
    while time.time() < t0 + 12:
        r = req(ports[2], "GET", "/v1/search?q=a", ident=ident)
        if r.status == 200:
            adm += 1
        last = time.time()
        nxt += 0.1
        d = nxt - time.time()
        if d > 0:
            time.sleep(d)
    T = last - t0
    record("R8_uneven_traffic_no_over_admission", adm <= 5 + 0.5 * T + 0.5, {"admitted": adm, "T": round(T, 2), "per_replica_bound": round(5 + 0.5 * T, 2)}, "static sharding strands quota (expected), must not exceed 5+0.5T on one replica", cat="rate")


def t_state_cap():
    # state-table bound: 10,000 identities per replica; depleted identities must not be reset
    p = sp(3)
    dep = uid("dep")
    for _ in range(6):
        req(p, "GET", "/v1/search?q=a", ident=dep)
    pre = req(p, "GET", "/v1/search?q=a", ident=dep).status
    m0 = req(p, "GET", "/_internal/metrics", ident="metricsprobe")
    res = tool("flood", f"127.0.0.1:{p}", 10100, 64, "cap" + uid("") + "_", timeout=160)
    st = res["statuses"]
    after = req(p, "GET", "/v1/search?q=a", ident=dep).status
    record("R9_state_cap_depleted_identity_not_reset", pre == 429 and after == 429, {"before": pre, "after_10100_new_ids": after, "flood_statuses": st, "elapsed": round(res["elapsed"], 2)}, cat="rate")
    n503 = st.get("503", 0)
    record("R9b_state_cap_fail_closed_503_when_full(info)", None, {"503_count": n503, "200_count": st.get("200", 0), "elapsed": round(res["elapsed"], 2)},
           "expect ~100 x 503 if flood finishes <2s (nothing evictable); fewer if slower flood let entries refill", cat="info")
    time.sleep(2.5)
    again = req(p, "GET", "/v1/search?q=a", ident=uid("after")).status
    record("R9c_state_cap_recovers_after_refill", again == 200, {"status_after_2.5s": again}, cat="rate")
