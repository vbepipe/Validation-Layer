package main

import (
	"encoding/json"
	"fmt"
	"io"
	"math/rand"
	"net/http"
	"os"
	"sort"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"time"
)

func newClient(conns int) *http.Client {
	return &http.Client{
		Timeout: 10 * time.Second,
		Transport: &http.Transport{
			MaxIdleConns:        conns,
			MaxIdleConnsPerHost: conns,
			IdleConnTimeout:     60 * time.Second,
			DisableCompression:  true,
		},
	}
}

func do(c *http.Client, req *http.Request) (int, error) {
	resp, err := c.Do(req)
	if err != nil {
		return 0, err
	}
	io.Copy(io.Discard, resp.Body)
	resp.Body.Close()
	return resp.StatusCode, nil
}

func searchReq(addr, id, q string) *http.Request {
	req, _ := http.NewRequest("GET", "http://"+addr+"/v1/search?q="+q, nil)
	req.Header.Set("X-Verified-Client-ID", id)
	return req
}

// burst addr id n conc
func burst() {
	addr, id := os.Args[2], os.Args[3]
	n, _ := strconv.Atoi(os.Args[4])
	conc, _ := strconv.Atoi(os.Args[5])
	c := newClient(conc)
	var mu sync.Mutex
	st := map[string]int{}
	var wg sync.WaitGroup
	sem := make(chan struct{}, conc)
	start := time.Now()
	for i := 0; i < n; i++ {
		wg.Add(1)
		sem <- struct{}{}
		go func() {
			defer wg.Done()
			code, err := do(c, searchReq(addr, id, "burst"))
			k := strconv.Itoa(code)
			if err != nil {
				k = "err"
			}
			mu.Lock()
			st[k]++
			mu.Unlock()
			<-sem
		}()
	}
	wg.Wait()
	b, _ := json.Marshal(map[string]any{"statuses": st, "elapsed": time.Since(start).Seconds()})
	fmt.Println(string(b))
}

// flood addr n conc prefix
func flood() {
	addr := os.Args[2]
	n, _ := strconv.Atoi(os.Args[3])
	conc, _ := strconv.Atoi(os.Args[4])
	prefix := os.Args[5]
	c := newClient(conc)
	var mu sync.Mutex
	st := map[string]int{}
	var wg sync.WaitGroup
	sem := make(chan struct{}, conc)
	var first503 atomic.Int64
	first503.Store(-1)
	start := time.Now()
	for i := 0; i < n; i++ {
		wg.Add(1)
		sem <- struct{}{}
		go func(i int) {
			defer wg.Done()
			code, err := do(c, searchReq(addr, prefix+strconv.Itoa(i), "flood"))
			k := strconv.Itoa(code)
			if err != nil {
				k = "err"
			}
			if code == 503 {
				first503.CompareAndSwap(-1, int64(i))
			}
			mu.Lock()
			st[k]++
			mu.Unlock()
			<-sem
		}(i)
	}
	wg.Wait()
	b, _ := json.Marshal(map[string]any{"statuses": st, "elapsed": time.Since(start).Seconds()})
	fmt.Println(string(b))
}

type result struct {
	status int
	lat    time.Duration
	err    bool
}

// load basePort rps warm dur identities seed
func load() {
	basePort, _ := strconv.Atoi(os.Args[2])
	rps, _ := strconv.Atoi(os.Args[3])
	warm, _ := strconv.Atoi(os.Args[4])
	dur, _ := strconv.Atoi(os.Args[5])
	ids, _ := strconv.Atoi(os.Args[6])
	seed, _ := strconv.Atoi(os.Args[7])
	rng := rand.New(rand.NewSource(int64(seed)))
	total := (warm + dur) * rps
	routes := make([]byte, total)
	for i := range routes {
		x := rng.Intn(100)
		switch {
		case x < 70:
			routes[i] = 's'
		case x < 90:
			routes[i] = 'f'
		default:
			routes[i] = 'r'
		}
	}
	c := newClient(1024)
	res := make([]result, total)
	var wg sync.WaitGroup
	sem := make(chan struct{}, 6000)
	interval := time.Second / time.Duration(rps)
	start := time.Now()
	for i := 0; i < total; i++ {
		sched := start.Add(time.Duration(i) * interval)
		if d := time.Until(sched); d > 200*time.Microsecond {
			time.Sleep(d)
		}
		sem <- struct{}{}
		wg.Add(1)
		go func(i int, sched time.Time) {
			defer wg.Done()
			defer func() { <-sem }()
			ident := i % ids
			port := basePort + ident%4
			addr := "127.0.0.1:" + strconv.Itoa(port)
			var req *http.Request
			switch routes[i] {
			case 's':
				req, _ = http.NewRequest("GET", "http://"+addr+"/v1/search?q=term"+strconv.Itoa(i), nil)
			case 'f':
				req, _ = http.NewRequest("GET", "http://"+addr+"/v1/files/file"+strconv.Itoa(i), nil)
			default:
				req, _ = http.NewRequest("POST", "http://"+addr+"/v1/tools/resolve", strings.NewReader(`{"host":"host`+strconv.Itoa(i)+`.example.com"}`))
				req.Header.Set("Content-Type", "application/json")
			}
			req.Header.Set("X-Verified-Client-ID", "load"+strconv.Itoa(ident))
			code, err := do(c, req)
			res[i] = result{code, time.Since(sched), err != nil}
		}(i, sched)
	}
	wg.Wait()
	wall := time.Since(start).Seconds()
	from := warm * rps
	var lats []float64
	st := map[string]int{}
	ok := 0
	errs := 0
	for _, r := range res[from:] {
		k := strconv.Itoa(r.status)
		if r.err {
			k = "err"
		}
		st[k]++
		if r.status == 200 && !r.err {
			ok++
		} else {
			errs++
		}
		lats = append(lats, float64(r.lat.Microseconds())/1000.0)
	}
	sort.Float64s(lats)
	pct := func(p float64) float64 { return lats[int(float64(len(lats)-1)*p)] }
	n := len(lats)
	out := map[string]any{
		"offered_rps": float64(n) / float64(dur), "completed_ok_rps": float64(ok) / float64(dur),
		"measured_requests": n, "ok": ok, "non200": errs, "error_rate": float64(errs) / float64(n),
		"statuses": st, "p50_ms": pct(0.5), "p99_ms": pct(0.99), "max_ms": lats[n-1], "wall_s": wall,
	}
	b, _ := json.Marshal(out)
	fmt.Println(string(b))
}

// conc addr path n  : n simultaneous GETs, unique identities, body discarded
func conc() {
	addr, path := os.Args[2], os.Args[3]
	n, _ := strconv.Atoi(os.Args[4])
	c := newClient(n)
	var mu sync.Mutex
	st := map[string]int{}
	var bytesTotal atomic.Int64
	var wg sync.WaitGroup
	start := time.Now()
	for i := 0; i < n; i++ {
		wg.Add(1)
		go func(i int) {
			defer wg.Done()
			req, _ := http.NewRequest("GET", "http://"+addr+path, nil)
			req.Header.Set("X-Verified-Client-ID", "m"+strconv.Itoa(i)+"x"+strconv.FormatInt(time.Now().UnixNano(), 36))
			resp, err := c.Do(req)
			k := "err"
			if err == nil {
				nb, _ := io.Copy(io.Discard, resp.Body)
				bytesTotal.Add(nb)
				resp.Body.Close()
				k = strconv.Itoa(resp.StatusCode)
			}
			mu.Lock()
			st[k]++
			mu.Unlock()
		}(i)
	}
	wg.Wait()
	b, _ := json.Marshal(map[string]any{"statuses": st, "elapsed": time.Since(start).Seconds(), "bytes": bytesTotal.Load()})
	fmt.Println(string(b))
}

func main() {
	switch os.Args[1] {
	case "burst":
		burst()
	case "flood":
		flood()
	case "load":
		load()
	case "conc":
		conc()
	}
}
