package main

import (
	"bytes"
	"container/heap"
	"context"
	"crypto/hmac"
	"crypto/rand"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"log"
	"math"
	"mime"
	"net"
	"net/http"
	"net/url"
	"os"
	"os/signal"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"syscall"
	"time"
	"unicode/utf8"
)

const (
	maxHeaderBytes  = 16 << 10
	maxTargetBytes  = 8 << 10
	maxRequestBody  = 64 << 10
	maxResponseBody = 1 << 20
	maxLogEvents    = 8192
	maxConcurrent   = 512
	maxClients      = 10000
)

type origin struct{ u *url.URL }

func parseOrigin(raw string) (*origin, error) {
	if raw == "" {
		return nil, errors.New("missing origin")
	}
	u, err := url.Parse(raw)
	if err != nil || u == nil {
		return nil, errors.New("invalid origin")
	}
	if !strings.EqualFold(u.Scheme, "http") || u.Host == "" || u.User != nil || u.Opaque != "" || u.RawQuery != "" || u.ForceQuery || strings.Contains(raw, "#") || u.Fragment != "" || u.RawFragment != "" || (u.Path != "" && u.Path != "/") || u.RawPath != "" {
		return nil, errors.New("invalid origin")
	}
	if u.Hostname() == "" {
		return nil, errors.New("invalid origin")
	}
	if p := u.Port(); p != "" {
		n, e := strconv.Atoi(p)
		if e != nil || n < 1 || n > 65535 {
			return nil, errors.New("invalid origin")
		}
	}
	// Treat a trailing slash as the empty origin path, not as a prefix for routes.
	u.Scheme = "http"
	u.Path, u.RawPath, u.RawQuery, u.ForceQuery = "", "", "", false
	return &origin{u: u}, nil
}

func (o *origin) target(path, rawQuery string, forceQuery bool) *url.URL {
	return &url.URL{Scheme: o.u.Scheme, Host: o.u.Host, Path: path, RawQuery: rawQuery, ForceQuery: forceQuery}
}

type logEvent struct {
	RequestID string `json:"request_id"`
	EventID   string `json:"event_id"`
	Timestamp string `json:"timestamp"`
	Method    string `json:"method"`
	Route     string `json:"route"`
	Status    int    `json:"status"`
	Duration  int64  `json:"duration_ms"`
	Outcome   string `json:"outcome"`
	Reason    string `json:"reason"`
	ClientID  string `json:"client_id"`
}

type logManager struct {
	queue               chan []byte
	reserved            int64
	reservationFailures uint64
	deliveryFailures    uint64
	unhealthy           atomic.Bool
	key                 [32]byte
	bootID              string
	requestSequence     uint64
	eventSequence       uint64
	writer              io.Writer
}

func newLogManager() (*logManager, error) {
	m := &logManager{queue: make(chan []byte, maxLogEvents), writer: os.Stdout}
	var seed [40]byte
	if _, err := rand.Read(seed[:]); err != nil {
		return nil, err
	}
	copy(m.key[:], seed[:32])
	m.bootID = hex.EncodeToString(seed[32:])
	go m.run()
	return m, nil
}

func saturatingIncrement(p *uint64) {
	for {
		old := atomic.LoadUint64(p)
		if old == ^uint64(0) || atomic.CompareAndSwapUint64(p, old, old+1) {
			return
		}
	}
}

func (m *logManager) reserve() bool {
	if m.unhealthy.Load() {
		saturatingIncrement(&m.reservationFailures)
		return false
	}
	for {
		old := atomic.LoadInt64(&m.reserved)
		if old >= maxLogEvents {
			saturatingIncrement(&m.reservationFailures)
			return false
		}
		if atomic.CompareAndSwapInt64(&m.reserved, old, old+1) {
			// A failed writer may race with the reservation. Undo it if unhealthy
			// was observed before this reservation is returned to the handler.
			if m.unhealthy.Load() {
				atomic.AddInt64(&m.reserved, -1)
				saturatingIncrement(&m.reservationFailures)
				return false
			}
			return true
		}
	}
}

func (m *logManager) nextRequestID() string {
	return "req-" + m.bootID + "-" + strconv.FormatUint(atomic.AddUint64(&m.requestSequence, 1), 36)
}

func (m *logManager) nextEventID() string {
	return "evt-" + m.bootID + "-" + strconv.FormatUint(atomic.AddUint64(&m.eventSequence, 1), 36)
}

func (m *logManager) pseudonym(identity string) string {
	mac := hmac.New(sha256.New, m.key[:])
	_, _ = mac.Write([]byte(identity))
	return hex.EncodeToString(mac.Sum(nil)[:12])
}

func (m *logManager) emit(ev logEvent) {
	b, err := json.Marshal(ev)
	if err != nil || len(b)+1 > 2048 {
		// Fixed, bounded fallback; no raw request data is used.
		b = []byte(`{"request_id":"invalid","event_id":"invalid","timestamp":"1970-01-01T00:00:00Z","method":"OTHER","route":"unmatched","status":500,"duration_ms":0,"outcome":"error","reason":"event_encoding_failed","client_id":"unverified"}`)
	}
	b = append(b, '\n')
	// Reservations include in-flight handlers, so a reserved handler always has
	// room in this queue even if the output writer is blocked.
	m.queue <- b
}

func (m *logManager) run() {
	for b := range m.queue {
		n, err := m.writer.Write(b)
		if err != nil || n != len(b) {
			m.unhealthy.Store(true)
			saturatingIncrement(&m.deliveryFailures)
		}
		atomic.AddInt64(&m.reserved, -1)
	}
}

type logMetrics struct {
	ReservationFailures uint64 `json:"logging_reservation_failures"`
	DeliveryFailures    uint64 `json:"logging_delivery_failures"`
	QueueDepth          int    `json:"queue_depth"`
	ReservationsInUse   int64  `json:"reservations_in_use"`
	Healthy             bool   `json:"logging_healthy"`
}

func (m *logManager) metrics() logMetrics {
	return logMetrics{
		ReservationFailures: atomic.LoadUint64(&m.reservationFailures),
		DeliveryFailures:    atomic.LoadUint64(&m.deliveryFailures),
		QueueDepth:          len(m.queue),
		ReservationsInUse:   atomic.LoadInt64(&m.reserved),
		Healthy:             !m.unhealthy.Load(),
	}
}

type bucketEntry struct {
	identity string
	tokens   float64
	last     time.Time
	fullAt   time.Time
	index    int
}

type bucketHeap []*bucketEntry

func (h bucketHeap) Len() int           { return len(h) }
func (h bucketHeap) Less(i, j int) bool { return h[i].fullAt.Before(h[j].fullAt) }
func (h bucketHeap) Swap(i, j int) {
	h[i], h[j] = h[j], h[i]
	h[i].index, h[j].index = i, j
}
func (h *bucketHeap) Push(x any) {
	b := x.(*bucketEntry)
	b.index = len(*h)
	*h = append(*h, b)
}
func (h *bucketHeap) Pop() any {
	old := *h
	last := len(old) - 1
	b := old[last]
	old[last] = nil
	*h = old[:last]
	b.index = -1
	return b
}

func bucketFullAt(now time.Time, tokens float64) time.Time {
	missing := 5.0 - tokens
	if missing <= 0 {
		return now
	}
	return now.Add(time.Duration((missing / 0.5) * float64(time.Second)))
}

type rateLimiter struct {
	mu        sync.Mutex
	buckets   map[string]*bucketEntry
	deadlines bucketHeap
}

func newRateLimiter() *rateLimiter {
	l := &rateLimiter{buckets: make(map[string]*bucketEntry, maxClients), deadlines: make(bucketHeap, 0, maxClients)}
	heap.Init(&l.deadlines)
	return l
}

// allow consumes a token atomically. The deadline heap permits eviction only
// when the earliest bucket should be fully replenished.
func (l *rateLimiter) allow(identity string, now time.Time) (allowed bool, retry time.Duration, stateFull bool) {
	l.mu.Lock()
	defer l.mu.Unlock()

	b := l.buckets[identity]
	if b == nil {
		if len(l.buckets) >= maxClients {
			for len(l.deadlines) > 0 && !l.deadlines[0].fullAt.After(now) {
				candidate := l.deadlines[0]
				elapsed := now.Sub(candidate.last).Seconds()
				if elapsed < 0 {
					elapsed = 0
				}
				candidate.tokens = math.Min(5.0, candidate.tokens+elapsed*0.5)
				if candidate.tokens < 5.0 {
					// Do not evict a possibly under-replenished entry due to
					// floating-point rounding; advance it and try the next one.
					candidate.last = now
					candidate.fullAt = bucketFullAt(now, candidate.tokens)
					heap.Fix(&l.deadlines, candidate.index)
					continue
				}
				heap.Pop(&l.deadlines)
				delete(l.buckets, candidate.identity)
				break
			}
			if len(l.buckets) >= maxClients {
				return false, 0, true
			}
		}
		b = &bucketEntry{identity: identity, tokens: 5.0, last: now, fullAt: now}
		l.buckets[identity] = b
		heap.Push(&l.deadlines, b)
	}

	elapsed := now.Sub(b.last).Seconds()
	if elapsed < 0 {
		elapsed = 0
	}
	b.tokens = math.Min(5.0, b.tokens+elapsed*0.5)
	b.last = now
	if b.tokens < 1.0 {
		waitSeconds := (1.0 - b.tokens) / 0.5
		if waitSeconds < 0 {
			waitSeconds = 0
		}
		b.fullAt = bucketFullAt(now, b.tokens)
		heap.Fix(&l.deadlines, b.index)
		return false, time.Duration(waitSeconds * float64(time.Second)), false
	}
	b.tokens -= 1.0
	b.fullAt = bucketFullAt(now, b.tokens)
	heap.Fix(&l.deadlines, b.index)
	return true, 0, false
}

type gateway struct {
	search   *origin
	files    *origin
	resolve  *origin
	client   *http.Client
	logs     *logManager
	limiter  *rateLimiter
	active   chan struct{}
	stopping atomic.Bool
}

type trackedWriter struct {
	http.ResponseWriter
	status int
	wrote  bool
}

func (w *trackedWriter) WriteHeader(code int) {
	if w.wrote {
		return
	}
	w.status, w.wrote = code, true
	w.ResponseWriter.WriteHeader(code)
}
func (w *trackedWriter) Write(p []byte) (int, error) {
	if !w.wrote {
		w.WriteHeader(http.StatusOK)
	}
	return w.ResponseWriter.Write(p)
}
func (w *trackedWriter) statusCode() int {
	if !w.wrote {
		return http.StatusOK
	}
	return w.status
}

func rawPathAndQuery(target string) (path, query string, hasQuery bool) {
	i := strings.IndexByte(target, '?')
	if i < 0 {
		return target, "", false
	}
	return target[:i], target[i+1:], true
}

func routeTemplate(rawPath string) string {
	switch {
	case rawPath == "/v1/search":
		return "/v1/search"
	case strings.HasPrefix(rawPath, "/v1/files/"):
		return "/v1/files/{file_id}"
	case rawPath == "/v1/tools/resolve":
		return "/v1/tools/resolve"
	case rawPath == "/healthz":
		return "/healthz"
	case rawPath == "/_internal/metrics":
		return "/_internal/metrics"
	default:
		return "unmatched"
	}
}

func isSpecialPath(path string) bool {
	return path == "/healthz" || path == "/_internal/metrics"
}

func validIdentity(values []string) (string, bool) {
	if len(values) != 1 {
		return "", false
	}
	s := values[0]
	if len(s) < 1 || len(s) > 128 {
		return "", false
	}
	for i := 0; i < len(s); i++ {
		c := s[i]
		if !((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == '_' || c == '-') {
			return "", false
		}
	}
	return s, true
}

func safeMethod(method string) string {
	if len(method) == 0 || len(method) > 32 {
		return "OTHER"
	}
	for i := 0; i < len(method); i++ {
		c := method[i]
		if !((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || strings.ContainsRune("!#$%&'*+-.^_`|~", rune(c))) {
			return "OTHER"
		}
	}
	return method
}

func headerLimitExceeded(r *http.Request) bool {
	count, bytesSeen := 0, 0
	for name, values := range r.Header {
		for _, value := range values {
			count++
			bytesSeen += len(name) + 2 + len(value) + 2
		}
	}
	// net/http stores Host separately and removes transfer-encoding/trailer
	// declaration fields while parsing. Account for those fields as well.
	if r.Host != "" {
		count++
		bytesSeen += len("Host") + 2 + len(r.Host) + 2
	}
	if len(r.TransferEncoding) > 0 {
		count++
		for _, value := range r.TransferEncoding {
			bytesSeen += len("Transfer-Encoding") + 2 + len(value) + 2
		}
	}
	if len(r.Trailer) > 0 {
		count++
		bytesSeen += len("Trailer") + 4 // field name, colon/space, and CRLF
		first := true
		for name := range r.Trailer {
			if !first {
				bytesSeen += 2
			}
			bytesSeen += len(name)
			first = false
		}
	}
	return count > 64 || bytesSeen > maxHeaderBytes
}

func readBodyLimited(w http.ResponseWriter, r *http.Request) ([]byte, error) {
	defer r.Body.Close()
	lr := http.MaxBytesReader(w, r.Body, maxRequestBody)
	b, err := io.ReadAll(lr)
	if err != nil {
		return b, err
	}
	if len(b) > maxRequestBody {
		return b, &http.MaxBytesError{Limit: maxRequestBody}
	}
	return b, nil
}

func validateSearch(rawQuery string, hasQuery bool) (string, bool) {
	if !hasQuery || rawQuery == "" || strings.Contains(rawQuery, "&") {
		return "", false
	}
	values, err := url.ParseQuery(rawQuery)
	if err != nil || len(values) != 1 {
		return "", false
	}
	v, ok := values["q"]
	if !ok || len(v) != 1 || len(v[0]) < 1 || len(v[0]) > 64 {
		return "", false
	}
	for i := 0; i < len(v[0]); i++ {
		c := v[0][i]
		if !((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == ' ' || c == '_' || c == '-') {
			return "", false
		}
	}
	return v[0], true
}

func validateFileID(rawPath string) (string, bool) {
	const prefix = "/v1/files/"
	if !strings.HasPrefix(rawPath, prefix) {
		return "", false
	}
	rawID := strings.TrimPrefix(rawPath, prefix)
	if rawID == "" || strings.Contains(rawID, "/") {
		return "", false
	}
	id, err := url.PathUnescape(rawID)
	if err != nil || len(id) < 1 || len(id) > 64 {
		return "", false
	}
	for i := 0; i < len(id); i++ {
		c := id[i]
		if !((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == '_' || c == '-') {
			return "", false
		}
	}
	return id, true
}

// For routes whose query semantics are not constrained, preserve the raw query
// but reject malformed escapes and fragments that would change URL parsing.
func validRawQuery(q string) bool {
	if strings.Contains(q, "#") {
		return false
	}
	for i := 0; i < len(q); i++ {
		if q[i] == '%' {
			if i+2 >= len(q) || !isHex(q[i+1]) || !isHex(q[i+2]) {
				return false
			}
			i += 2
		}
	}
	return true
}

func isHex(c byte) bool {
	return (c >= '0' && c <= '9') || (c >= 'a' && c <= 'f') || (c >= 'A' && c <= 'F')
}

func validHostname(host string) bool {
	if len(host) < 1 || len(host) > 253 || strings.HasSuffix(host, ".") {
		return false
	}
	for i := 0; i < len(host); i++ {
		if host[i] >= 0x80 {
			return false
		}
	}
	for _, label := range strings.Split(host, ".") {
		if len(label) < 1 || len(label) > 63 || label[0] == '-' || label[len(label)-1] == '-' {
			return false
		}
		for i := 0; i < len(label); i++ {
			c := label[i]
			if !((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == '-') {
				return false
			}
		}
	}
	return true
}

func validateResolve(contentTypes []string, body []byte) (string, bool) {
	if len(contentTypes) != 1 {
		return "", false
	}
	mediaType, params, err := mime.ParseMediaType(contentTypes[0])
	if err != nil || !strings.EqualFold(mediaType, "application/json") {
		return "", false
	}
	if len(params) > 1 {
		return "", false
	}
	if len(params) == 1 {
		charset, ok := params["charset"]
		if !ok || !strings.EqualFold(charset, "utf-8") {
			return "", false
		}
	}
	if !utf8.Valid(body) {
		return "", false
	}
	dec := json.NewDecoder(bytes.NewReader(body))
	first, err := dec.Token()
	if err != nil || first != json.Delim('{') {
		return "", false
	}
	seenHost, host := false, ""
	for dec.More() {
		tok, e := dec.Token()
		if e != nil {
			return "", false
		}
		key, ok := tok.(string)
		if !ok || key != "host" || seenHost {
			return "", false
		}
		seenHost = true
		var raw json.RawMessage
		if e := dec.Decode(&raw); e != nil {
			return "", false
		}
		if e := json.Unmarshal(raw, &host); e != nil {
			return "", false
		}
	}
	last, err := dec.Token()
	if err != nil || last != json.Delim('}') || !seenHost {
		return "", false
	}
	var trailing json.RawMessage
	if err := dec.Decode(&trailing); err != io.EOF {
		return "", false
	}
	if !validHostname(host) {
		return "", false
	}
	return strings.ToLower(host), true
}

var hopHeaders = map[string]struct{}{
	"connection": {}, "proxy-connection": {}, "keep-alive": {},
	"proxy-authenticate": {}, "proxy-authorization": {}, "te": {},
	"trailer": {}, "transfer-encoding": {}, "upgrade": {},
}

func connectionNominations(h http.Header) map[string]struct{} {
	out := make(map[string]struct{})
	for _, value := range h.Values("Connection") {
		for _, part := range strings.Split(value, ",") {
			name := strings.TrimSpace(part)
			if name != "" {
				out[strings.ToLower(name)] = struct{}{}
			}
		}
	}
	return out
}

func forwardedRequestHeaders(dst, src http.Header) {
	nominated := connectionNominations(src)
	for _, name := range []string{"Accept", "Content-Type", "If-None-Match"} {
		lower := strings.ToLower(name)
		if _, hop := hopHeaders[lower]; hop {
			continue
		}
		if _, nom := nominated[lower]; nom {
			continue
		}
		for _, value := range src.Values(name) {
			dst.Add(name, value)
		}
	}
}

func forwardedResponseHeaders(dst, src http.Header) {
	nominated := connectionNominations(src)
	for name, values := range src {
		lower := strings.ToLower(name)
		if _, hop := hopHeaders[lower]; hop {
			continue
		}
		if _, nom := nominated[lower]; nom {
			continue
		}
		for _, value := range values {
			dst.Add(name, value)
		}
	}
}

func requestTooLarge(w http.ResponseWriter, r *http.Request) {
	r.Close = true
	w.Header().Set("Connection", "close")
	httpError(w, http.StatusRequestEntityTooLarge)
}

func methodNotAllowed(w http.ResponseWriter, allow string) {
	w.Header().Set("Allow", allow)
	httpError(w, http.StatusMethodNotAllowed)
}

func httpError(w http.ResponseWriter, status int) {
	msg := http.StatusText(status)
	if msg == "" {
		msg = "Request Failed"
	}
	http.Error(w, msg, status)
}

func (g *gateway) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	rawPath, rawQuery, hasQuery := rawPathAndQuery(r.RequestURI)
	if g.stopping.Load() {
		httpError(w, http.StatusServiceUnavailable)
		return
	}
	if isSpecialPath(rawPath) {
		g.serveSpecial(w, r, rawPath)
		return
	}
	if !g.logs.reserve() {
		httpError(w, http.StatusServiceUnavailable)
		return
	}

	tw := &trackedWriter{ResponseWriter: w}
	started := time.Now()
	identityRaw, identityOK := validIdentity(r.Header.Values("X-Verified-Client-ID"))
	clientID := "unverified"
	if identityOK {
		clientID = g.logs.pseudonym(identityRaw)
	}
	ev := logEvent{
		RequestID: g.logs.nextRequestID(),
		EventID:   g.logs.nextEventID(),
		Timestamp: started.UTC().Format(time.RFC3339Nano),
		Method:    safeMethod(r.Method),
		Route:     routeTemplate(rawPath),
		ClientID:  clientID,
	}
	reason, outcome := "internal_error", "error"
	defer func() {
		if recover() != nil {
			if !tw.wrote {
				httpError(tw, http.StatusInternalServerError)
			}
			reason, outcome = "internal_error", "error"
		}
		ev.Status = tw.statusCode()
		if reason == "client_cancelled" && !tw.wrote {
			ev.Status = 499
		}
		ev.Duration = time.Since(started).Milliseconds()
		ev.Reason, ev.Outcome = reason, outcome
		g.logs.emit(ev)
	}()

	select {
	case g.active <- struct{}{}:
		defer func() { <-g.active }()
	default:
		reason, outcome = "concurrency_limit", "rejected"
		httpError(tw, http.StatusServiceUnavailable)
		return
	}
	if g.stopping.Load() {
		reason, outcome = "shutting_down", "rejected"
		httpError(tw, http.StatusServiceUnavailable)
		return
	}
	if r.ProtoMajor != 1 || r.ProtoMinor != 1 {
		reason, outcome = "unsupported_protocol", "rejected"
		httpError(tw, http.StatusBadRequest)
		return
	}
	if len(r.RequestURI) > maxTargetBytes {
		reason, outcome = "target_too_large", "rejected"
		requestTooLarge(tw, r)
		return
	}
	if headerLimitExceeded(r) {
		reason, outcome = "headers_too_large", "rejected"
		requestTooLarge(tw, r)
		return
	}
	if !identityOK {
		reason, outcome = "untrusted_identity", "rejected"
		httpError(tw, http.StatusUnauthorized)
		return
	}
	if r.ContentLength > maxRequestBody {
		reason, outcome = "body_too_large", "rejected"
		requestTooLarge(tw, r)
		return
	}

	body, bodyErr := readBodyLimited(tw, r)
	if bodyErr != nil {
		var maxErr *http.MaxBytesError
		if errors.As(bodyErr, &maxErr) {
			reason, outcome = "body_too_large", "rejected"
			requestTooLarge(tw, r)
			return
		}
		reason, outcome = "invalid_request_body", "rejected"
		httpError(tw, http.StatusBadRequest)
		return
	}

	var (
		upstream      *origin
		upstreamPath  string
		upstreamQuery string
		forceQuery    bool
		method        string
		canonicalBody []byte
	)
	switch {
	case rawPath == "/v1/search":
		if r.Method != http.MethodGet {
			reason, outcome = "method_not_allowed", "rejected"
			methodNotAllowed(tw, "GET")
			return
		}
		term, ok := validateSearch(rawQuery, hasQuery)
		if !ok {
			reason, outcome = "invalid_search_query", "rejected"
			httpError(tw, http.StatusBadRequest)
			return
		}
		upstream, upstreamPath, method = g.search, "/v1/search", http.MethodGet
		upstreamQuery = url.Values{"q": []string{term}}.Encode()
	case strings.HasPrefix(rawPath, "/v1/files/"):
		if r.Method != http.MethodGet {
			reason, outcome = "method_not_allowed", "rejected"
			methodNotAllowed(tw, "GET")
			return
		}
		fileID, ok := validateFileID(rawPath)
		if !ok || (hasQuery && !validRawQuery(rawQuery)) {
			reason, outcome = "invalid_file_request", "rejected"
			httpError(tw, http.StatusBadRequest)
			return
		}
		upstream, upstreamPath, method = g.files, "/v1/files/"+url.PathEscape(fileID), http.MethodGet
		upstreamQuery, forceQuery = rawQuery, hasQuery && rawQuery == ""
	case rawPath == "/v1/tools/resolve":
		if r.Method != http.MethodPost {
			reason, outcome = "method_not_allowed", "rejected"
			methodNotAllowed(tw, "POST")
			return
		}
		if hasQuery && !validRawQuery(rawQuery) {
			reason, outcome = "invalid_resolve_query", "rejected"
			httpError(tw, http.StatusBadRequest)
			return
		}
		host, ok := validateResolve(r.Header.Values("Content-Type"), body)
		if !ok {
			reason, outcome = "invalid_resolve_json", "rejected"
			httpError(tw, http.StatusBadRequest)
			return
		}
		canonicalBody, _ = json.Marshal(struct {
			Host string `json:"host"`
		}{Host: host})
		upstream, upstreamPath, method = g.resolve, "/v1/tools/resolve", http.MethodPost
		upstreamQuery, forceQuery = rawQuery, hasQuery && rawQuery == ""
	default:
		reason, outcome = "not_found", "rejected"
		httpError(tw, http.StatusNotFound)
		return
	}

	allowed, retry, full := g.limiter.allow(identityRaw, time.Now())
	if full {
		reason, outcome = "rate_state_full", "rejected"
		httpError(tw, http.StatusServiceUnavailable)
		return
	}
	if !allowed {
		reason, outcome = "quota_exhausted", "rejected"
		seconds := int(math.Ceil(retry.Seconds()))
		if seconds < 1 {
			seconds = 1
		}
		tw.Header().Set("Retry-After", strconv.Itoa(seconds))
		httpError(tw, http.StatusTooManyRequests)
		return
	}

	var bodyReader io.Reader
	if method == http.MethodPost {
		bodyReader = bytes.NewReader(canonicalBody)
	}
	target := upstream.target(upstreamPath, upstreamQuery, forceQuery)
	upReq, err := http.NewRequestWithContext(r.Context(), method, target.String(), bodyReader)
	if err != nil {
		// Route-specific raw-query validation above keeps malformed client data
		// from being misreported as an upstream failure.
		reason, outcome = "upstream_request_failed", "error"
		httpError(tw, http.StatusBadGateway)
		return
	}
	forwardedRequestHeaders(upReq.Header, r.Header)
	resp, err := g.client.Do(upReq)
	if err != nil {
		if r.Context().Err() != nil {
			reason, outcome = "client_cancelled", "error"
			return
		}
		if isTimeout(err) {
			reason, outcome = "upstream_timeout", "error"
			httpError(tw, http.StatusGatewayTimeout)
			return
		}
		reason, outcome = "upstream_failure", "error"
		httpError(tw, http.StatusBadGateway)
		return
	}
	defer resp.Body.Close()
	if resp.ContentLength > maxResponseBody {
		reason, outcome = "upstream_response_too_large", "error"
		httpError(tw, http.StatusBadGateway)
		return
	}
	responseBody, readErr := io.ReadAll(io.LimitReader(resp.Body, maxResponseBody+1))
	if len(responseBody) > maxResponseBody {
		reason, outcome = "upstream_response_too_large", "error"
		httpError(tw, http.StatusBadGateway)
		return
	}
	if readErr != nil {
		if r.Context().Err() != nil {
			reason, outcome = "client_cancelled", "error"
			return
		}
		if isTimeout(readErr) {
			reason, outcome = "upstream_timeout", "error"
			httpError(tw, http.StatusGatewayTimeout)
			return
		}
		reason, outcome = "upstream_failure", "error"
		httpError(tw, http.StatusBadGateway)
		return
	}
	forwardedResponseHeaders(tw.Header(), resp.Header)
	tw.WriteHeader(resp.StatusCode)
	if len(responseBody) > 0 {
		if n, err := tw.Write(responseBody); err != nil || n != len(responseBody) {
			reason, outcome = "client_write_failed", "error"
			return
		}
	}
	reason, outcome = "upstream_response", "proxied"
}

func (g *gateway) serveSpecial(w http.ResponseWriter, r *http.Request, path string) {
	if len(r.RequestURI) > maxTargetBytes || headerLimitExceeded(r) {
		requestTooLarge(w, r)
		return
	}
	if r.ProtoMajor != 1 || r.ProtoMinor != 1 {
		httpError(w, http.StatusBadRequest)
		return
	}
	if r.ContentLength > maxRequestBody {
		requestTooLarge(w, r)
		return
	}
	body, err := readBodyLimited(w, r)
	if err != nil {
		var maxErr *http.MaxBytesError
		if errors.As(err, &maxErr) {
			requestTooLarge(w, r)
		} else {
			httpError(w, http.StatusBadRequest)
		}
		return
	}
	_ = body
	if r.Method != http.MethodGet {
		methodNotAllowed(w, "GET")
		return
	}
	if path == "/healthz" {
		w.Header().Set("Content-Type", "text/plain; charset=utf-8")
		w.Header().Set("Cache-Control", "no-store")
		w.WriteHeader(http.StatusOK)
		_, _ = io.WriteString(w, "ok\n")
		return
	}
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.Header().Set("Cache-Control", "no-store")
	_ = json.NewEncoder(w).Encode(g.logs.metrics())
}

func isTimeout(err error) bool {
	if errors.Is(err, context.DeadlineExceeded) {
		return true
	}
	var ne net.Error
	return errors.As(err, &ne) && ne.Timeout()
}

func newHTTPClient() *http.Client {
	transport := &http.Transport{
		Proxy:                 nil,
		DialContext:           (&net.Dialer{Timeout: 2 * time.Second, KeepAlive: 30 * time.Second}).DialContext,
		ForceAttemptHTTP2:     false,
		MaxIdleConns:          512,
		MaxIdleConnsPerHost:   128,
		MaxConnsPerHost:       maxConcurrent,
		IdleConnTimeout:       30 * time.Second,
		ResponseHeaderTimeout: 2 * time.Second,
		DisableCompression:    true,
	}
	return &http.Client{
		Transport: transport,
		Timeout:   2 * time.Second,
		CheckRedirect: func(_ *http.Request, _ []*http.Request) error {
			return http.ErrUseLastResponse
		},
	}
}

func run() int {
	replica := os.Getenv("REPLICA_ID")
	if replica != "0" && replica != "1" && replica != "2" && replica != "3" {
		fmt.Fprintln(os.Stderr, "gateway: REPLICA_ID must be 0, 1, 2, or 3")
		return 2
	}
	search, err := parseOrigin(os.Getenv("SEARCH_BACKEND_URL"))
	if err != nil {
		fmt.Fprintln(os.Stderr, "gateway: invalid SEARCH_BACKEND_URL")
		return 2
	}
	files, err := parseOrigin(os.Getenv("FILES_BACKEND_URL"))
	if err != nil {
		fmt.Fprintln(os.Stderr, "gateway: invalid FILES_BACKEND_URL")
		return 2
	}
	resolve, err := parseOrigin(os.Getenv("RESOLVE_BACKEND_URL"))
	if err != nil {
		fmt.Fprintln(os.Stderr, "gateway: invalid RESOLVE_BACKEND_URL")
		return 2
	}
	addr := os.Getenv("GATEWAY_ADDR")
	if addr == "" {
		addr = "127.0.0.1:8080"
	}
	logs, err := newLogManager()
	if err != nil {
		fmt.Fprintln(os.Stderr, "gateway: unable to initialize logging")
		return 2
	}
	g := &gateway{
		search: search, files: files, resolve: resolve,
		client: newHTTPClient(), logs: logs, limiter: newRateLimiter(),
		active: make(chan struct{}, maxConcurrent),
	}
	server := &http.Server{
		Addr:              addr,
		Handler:           g,
		ReadHeaderTimeout: 5 * time.Second,
		ReadTimeout:       10 * time.Second,
		WriteTimeout:      3 * time.Second,
		IdleTimeout:       30 * time.Second,
		MaxHeaderBytes:    maxHeaderBytes,
		ErrorLog:          log.New(io.Discard, "", 0),
	}
	listener, err := net.Listen("tcp", addr)
	if err != nil {
		fmt.Fprintln(os.Stderr, "gateway: unable to listen")
		return 2
	}
	serveErr := make(chan error, 1)
	go func() { serveErr <- server.Serve(listener) }()

	signals := make(chan os.Signal, 1)
	signal.Notify(signals, syscall.SIGTERM, os.Interrupt)
	defer signal.Stop(signals)
	select {
	case <-signals:
		g.stopping.Store(true)
		server.SetKeepAlivesEnabled(false)
		shutdownCtx, cancel := context.WithTimeout(context.Background(), 2500*time.Millisecond)
		shutdownDone := make(chan error, 1)
		go func() { shutdownDone <- server.Shutdown(shutdownCtx) }()
		select {
		case err := <-shutdownDone:
			if err != nil {
				_ = server.Close()
			}
		case <-shutdownCtx.Done():
			_ = server.Close()
		}
		cancel()
		// Best effort: an OS stdout write may block indefinitely and cannot be
		// portably interrupted. The process still exits by the three-second cap.
		deadline := time.Now().Add(500 * time.Millisecond)
		for time.Now().Before(deadline) {
			if atomic.LoadInt64(&logs.reserved) == 0 && len(logs.queue) == 0 {
				os.Exit(0)
			}
			time.Sleep(5 * time.Millisecond)
		}
		os.Exit(0)
		return 0
	case err := <-serveErr:
		if err != nil && !errors.Is(err, http.ErrServerClosed) {
			fmt.Fprintln(os.Stderr, "gateway: server stopped unexpectedly")
			return 2
		}
		return 0
	}
}

func main() { os.Exit(run()) }
