package main

import (
	"bytes"
	"container/heap"
	"context"
	"crypto/hmac"
	"crypto/rand"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"log"
	"math"
	"mime"
	"net"
	"net/http"
	"net/url"
	"os"
	"os/signal"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"syscall"
	"time"
	"unicode/utf8"
)

const (
	maxHeaderBytes       = 16 << 10
	parserHeaderBytes    = 128 << 10
	maxTargetBytes       = 8 << 10
	maxRequestBody       = 64 << 10
	maxResponseBody      = 1 << 20
	maxLogEvents         = 8192
	maxConcurrent        = 512
	maxClients           = 10000
	maxResponseBuffers   = 128
	maxHeaderScanBytes   = parserHeaderBytes + (8 << 10)
	maxHeaderMetaPending = 1024
)

type origin struct {
	u *url.URL
}

func parseOrigin(raw string) (*origin, error) {
	if raw == "" {
		return nil, errors.New("missing origin")
	}

	u, err := url.Parse(raw)
	if err != nil || u == nil {
		return nil, errors.New("invalid origin")
	}

	if !strings.EqualFold(u.Scheme, "http") ||
		u.Host == "" ||
		u.User != nil ||
		u.Opaque != "" ||
		u.Path != "" ||
		u.RawPath != "" ||
		u.RawQuery != "" ||
		u.ForceQuery ||
		u.Fragment != "" ||
		strings.Contains(raw, "#") {
		return nil, errors.New("invalid origin")
	}

	if u.Hostname() == "" {
		return nil, errors.New("invalid origin")
	}

	if p := u.Port(); p != "" {
		n, e := strconv.Atoi(p)
		if e != nil || n < 1 || n > 65535 {
			return nil, errors.New("invalid origin")
		}
	}

	u.Scheme = "http"
	return &origin{u: u}, nil
}

func (o *origin) target(path, rawQuery string) *url.URL {
	return &url.URL{
		Scheme:   o.u.Scheme,
		Host:     o.u.Host,
		Path:     path,
		RawQuery: rawQuery,
	}
}

type headerMeta struct {
	targetBytes int
	headerBytes int
	fields      int
	valid       bool
}

const (
	scanHeader = iota
	scanFixedBody
	scanChunkSize
	scanChunkData
	scanChunkCRLF
	scanTrailers
)

// accountingConn observes request bytes without changing them or replacing
// net/http's parser. Its framing scanner associates raw header counts with
// parsed requests; net/http remains responsible for HTTP framing validation.
type accountingConn struct {
	net.Conn

	mu          sync.Mutex
	state       int
	headerBuf   []byte
	headerTail  []byte
	headerDrop  bool
	lineBuf     []byte
	bodyRemain  int64
	chunkCRLF   int
	pending     []headerMeta
	pendingHead int
}

func newAccountingConn(c net.Conn) *accountingConn {
	return &accountingConn{
		Conn:       c,
		state:      scanHeader,
		headerBuf:  make([]byte, 0, 1024),
		headerTail: make([]byte, 0, 4),
		lineBuf:    make([]byte, 0, 128),
		pending:    make([]headerMeta, 0, 8),
	}
}

func (c *accountingConn) Read(p []byte) (int, error) {
	n, err := c.Conn.Read(p)
	if n > 0 {
		c.observe(p[:n])
	}
	return n, err
}

func (c *accountingConn) pushMeta(m headerMeta) {
	if len(c.pending)-c.pendingHead >= maxHeaderMetaPending {
		return
	}

	if c.pendingHead > 0 && c.pendingHead >= len(c.pending)/2 {
		copy(c.pending, c.pending[c.pendingHead:])
		c.pending = c.pending[:len(c.pending)-c.pendingHead]
		c.pendingHead = 0
	}

	c.pending = append(c.pending, m)
}

func (c *accountingConn) nextMeta() (headerMeta, bool) {
	c.mu.Lock()
	defer c.mu.Unlock()

	if c.pendingHead >= len(c.pending) {
		return headerMeta{}, false
	}

	m := c.pending[c.pendingHead]
	c.pendingHead++

	if c.pendingHead == len(c.pending) {
		c.pending = c.pending[:0]
		c.pendingHead = 0
	}

	return m, true
}

func parseRawHeaderBlock(block []byte) (headerMeta, int, int64) {
	m := headerMeta{valid: true}

	first := bytes.Index(block, []byte("\r\n"))
	if first < 0 {
		return headerMeta{}, scanHeader, 0
	}

	requestLine := strings.Fields(string(block[:first]))
	if len(requestLine) >= 2 {
		m.targetBytes = len(requestLine[1])
	}

	// Count raw header bytes independently of the request line.
	m.headerBytes = len(block) - (first + 2)
	if m.headerBytes < 0 {
		m.headerBytes = 0
	}

	var contentLength int64
	chunked := false

	// Field lines retain their CRLF; omit only the final CRLF of the block.
	sectionEnd := len(block) - 2
	if sectionEnd > first+2 {
		section := string(block[first+2 : sectionEnd])

		for _, line := range strings.Split(section, "\r\n") {
			if line == "" || line[0] == ' ' || line[0] == '\t' {
				continue
			}

			colon := strings.IndexByte(line, ':')
			if colon <= 0 {
				continue
			}

			m.fields++

			name := strings.TrimSpace(line[:colon])
			value := strings.TrimSpace(line[colon+1:])

			switch {
			case strings.EqualFold(name, "Transfer-Encoding") &&
				strings.Contains(strings.ToLower(value), "chunked"):
				chunked = true

			case strings.EqualFold(name, "Content-Length"):
				if n, err := strconv.ParseInt(value, 10, 64); err == nil && n > 0 {
					contentLength = n
				}
			}
		}
	}

	if chunked {
		return m, scanChunkSize, 0
	}
	if contentLength > 0 {
		return m, scanFixedBody, contentLength
	}

	return m, scanHeader, 0
}

func (c *accountingConn) finishHeader() {
	m, state, remain := parseRawHeaderBlock(c.headerBuf)
	c.pushMeta(m)

	c.headerBuf = c.headerBuf[:0]
	c.headerTail = c.headerTail[:0]
	c.headerDrop = false
	c.lineBuf = c.lineBuf[:0]
	c.bodyRemain = remain

	switch state {
	case scanFixedBody:
		if remain > 0 {
			c.state = scanFixedBody
		} else {
			c.state = scanHeader
		}
	case scanChunkSize:
		c.state = scanChunkSize
	default:
		c.state = scanHeader
	}
}

func (c *accountingConn) observe(p []byte) {
	c.mu.Lock()
	defer c.mu.Unlock()

	for _, b := range p {
		switch c.state {
		case scanHeader:
			if !c.headerDrop {
				if len(c.headerBuf) < maxHeaderScanBytes {
					c.headerBuf = append(c.headerBuf, b)
				} else {
					c.headerDrop = true
					c.headerBuf = c.headerBuf[:0]
				}
			}

			c.headerTail = append(c.headerTail, b)
			if len(c.headerTail) > 4 {
				copy(c.headerTail, c.headerTail[len(c.headerTail)-4:])
				c.headerTail = c.headerTail[:4]
			}

			if len(c.headerTail) == 4 &&
				bytes.Equal(c.headerTail, []byte("\r\n\r\n")) {
				if !c.headerDrop {
					c.finishHeader()
				} else {
					c.headerBuf = c.headerBuf[:0]
					c.headerTail = c.headerTail[:0]
					c.headerDrop = false
					c.state = scanHeader
				}
			}

		case scanFixedBody:
			c.bodyRemain--
			if c.bodyRemain <= 0 {
				c.bodyRemain = 0
				c.state = scanHeader
				c.headerBuf = c.headerBuf[:0]
				c.headerTail = c.headerTail[:0]
			}

		case scanChunkSize:
			c.lineBuf = append(c.lineBuf, b)

			if len(c.lineBuf) >= 2 &&
				c.lineBuf[len(c.lineBuf)-2] == '\r' &&
				c.lineBuf[len(c.lineBuf)-1] == '\n' {

				line := string(c.lineBuf[:len(c.lineBuf)-2])
				c.lineBuf = c.lineBuf[:0]

				if semicolon := strings.IndexByte(line, ';'); semicolon >= 0 {
					line = line[:semicolon]
				}

				n, err := strconv.ParseUint(strings.TrimSpace(line), 16, 63)
				if err != nil {
					// Observation only; net/http handles malformed framing.
					c.state = scanHeader
				} else if n == 0 {
					c.state = scanTrailers
				} else {
					c.bodyRemain = int64(n)
					c.state = scanChunkData
				}
			} else if len(c.lineBuf) > 8192 {
				c.lineBuf = c.lineBuf[:0]
				c.state = scanHeader
			}

		case scanChunkData:
			c.bodyRemain--
			if c.bodyRemain <= 0 {
				c.chunkCRLF = 2
				c.state = scanChunkCRLF
			}

		case scanChunkCRLF:
			c.chunkCRLF--
			if c.chunkCRLF <= 0 {
				c.state = scanChunkSize
			}

		case scanTrailers:
			c.lineBuf = append(c.lineBuf, b)

			if len(c.lineBuf) >= 2 &&
				c.lineBuf[len(c.lineBuf)-2] == '\r' &&
				c.lineBuf[len(c.lineBuf)-1] == '\n' {

				if len(c.lineBuf) == 2 {
					c.state = scanHeader
					c.headerBuf = c.headerBuf[:0]
					c.headerTail = c.headerTail[:0]
				}

				c.lineBuf = c.lineBuf[:0]
			} else if len(c.lineBuf) > 8192 {
				c.lineBuf = c.lineBuf[:0]
				c.state = scanHeader
			}
		}
	}
}

type accountingListener struct {
	net.Listener
}

func (l accountingListener) Accept() (net.Conn, error) {
	c, err := l.Listener.Accept()
	if err != nil {
		return nil, err
	}
	return newAccountingConn(c), nil
}

type connContextKey struct{}

func rawHeaderMeta(r *http.Request) (headerMeta, bool) {
	if r == nil {
		return headerMeta{}, false
	}

	if ac, ok := r.Context().Value(connContextKey{}).(*accountingConn); ok {
		return ac.nextMeta()
	}

	return headerMeta{}, false
}

type logEvent struct {
	RequestID string `json:"request_id"`
	EventID   string `json:"event_id"`
	Timestamp string `json:"timestamp"`
	Method    string `json:"method"`
	Route     string `json:"route"`
	Status    int    `json:"status"`
	Duration  int64  `json:"duration_ms"`
	Outcome   string `json:"outcome"`
	Reason    string `json:"reason"`
	ClientID  string `json:"client_id"`
}

type logManager struct {
	queue               chan []byte
	writer              io.Writer
	key                 [32]byte
	bootID              string
	requestSequence     atomic.Uint64
	eventSequence       atomic.Uint64
	admitMu             sync.Mutex
	reserved            int
	unhealthy           bool
	reservationFailures atomic.Uint64
	deliveryFailures    atomic.Uint64
}

func newLogManager() (*logManager, error) {
	m := &logManager{
		queue:  make(chan []byte, maxLogEvents),
		writer: os.Stdout,
	}

	var seed [40]byte
	if _, err := rand.Read(seed[:]); err != nil {
		return nil, err
	}

	copy(m.key[:], seed[:32])
	m.bootID = hex.EncodeToString(seed[32:])

	go m.run()
	return m, nil
}

func saturatingIncrement(p *atomic.Uint64) {
	for {
		old := p.Load()
		if old == ^uint64(0) || p.CompareAndSwap(old, old+1) {
			return
		}
	}
}

func (m *logManager) reserve() bool {
	m.admitMu.Lock()
	defer m.admitMu.Unlock()

	if m.unhealthy || m.reserved >= maxLogEvents {
		saturatingIncrement(&m.reservationFailures)
		return false
	}

	m.reserved++
	return true
}

func (m *logManager) releaseReservation() {
	m.admitMu.Lock()
	if m.reserved > 0 {
		m.reserved--
	}
	m.admitMu.Unlock()
}

func (m *logManager) nextRequestID() string {
	n := m.requestSequence.Add(1)
	return "req-" + m.bootID + "-" + strconv.FormatUint(n, 36)
}

func (m *logManager) nextEventID() string {
	n := m.eventSequence.Add(1)
	return "evt-" + m.bootID + "-" + strconv.FormatUint(n, 36)
}

func (m *logManager) pseudonym(identity string) string {
	mac := hmac.New(sha256.New, m.key[:])
	_, _ = mac.Write([]byte(identity))
	return hex.EncodeToString(mac.Sum(nil)[:12])
}

func (m *logManager) emit(ev logEvent) {
	b, err := json.Marshal(ev)
	if err != nil || len(b)+1 > 2048 {
		b = []byte(`{"request_id":"invalid","event_id":"invalid","timestamp":"1970-01-01T00:00:00Z","method":"OTHER","route":"unmatched","status":500,"duration_ms":0,"outcome":"error","reason":"event_encoding_failed","client_id":"unverified"}`)
	}

	b = append(b, '\n')

	// Queued and not-yet-emitted events each own a reservation. The total
	// reservation limit therefore prevents this bounded send from overflowing.
	m.queue <- b
}

func (m *logManager) run() {
	for b := range m.queue {
		n, err := m.writer.Write(b)
		if err != nil || n != len(b) {
			m.admitMu.Lock()
			m.unhealthy = true
			m.admitMu.Unlock()
			saturatingIncrement(&m.deliveryFailures)
		}

		m.releaseReservation()
	}
}

type logMetrics struct {
	ReservationFailures uint64 `json:"logging_reservation_failures"`
	DeliveryFailures    uint64 `json:"logging_delivery_failures"`
	QueueDepth          int    `json:"queue_depth"`
	ReservationsInUse   int    `json:"reservations_in_use"`
	Healthy             bool   `json:"logging_healthy"`
}

func (m *logManager) metrics() logMetrics {
	m.admitMu.Lock()
	reserved, healthy := m.reserved, !m.unhealthy
	m.admitMu.Unlock()

	return logMetrics{
		ReservationFailures: m.reservationFailures.Load(),
		DeliveryFailures:    m.deliveryFailures.Load(),
		QueueDepth:          len(m.queue),
		ReservationsInUse:   reserved,
		Healthy:             healthy,
	}
}

func (m *logManager) drained() bool {
	m.admitMu.Lock()
	reserved := m.reserved
	m.admitMu.Unlock()

	return reserved == 0 && len(m.queue) == 0
}

type bucketEntry struct {
	identity string
	tokens   float64
	last     time.Time
	fullAt   time.Time
	index    int
}

type bucketHeap []*bucketEntry

func (h bucketHeap) Len() int {
	return len(h)
}

func (h bucketHeap) Less(i, j int) bool {
	return h[i].fullAt.Before(h[j].fullAt)
}

func (h bucketHeap) Swap(i, j int) {
	h[i], h[j] = h[j], h[i]
	h[i].index = i
	h[j].index = j
}

func (h *bucketHeap) Push(x any) {
	b := x.(*bucketEntry)
	b.index = len(*h)
	*h = append(*h, b)
}

func (h *bucketHeap) Pop() any {
	old := *h
	n := len(old)
	b := old[n-1]
	old[n-1] = nil
	b.index = -1
	*h = old[:n-1]
	return b
}

func refillDuration(tokens float64) time.Duration {
	missing := 5.0 - tokens
	if missing <= 0 {
		return 0
	}

	return time.Duration(math.Ceil((missing / 0.5) * float64(time.Second)))
}

func refreshFullAt(b *bucketEntry) {
	b.fullAt = b.last.Add(refillDuration(b.tokens))
}

type rateLimiter struct {
	mu      sync.Mutex
	buckets map[string]*bucketEntry
	heap    bucketHeap
}

func newRateLimiter() *rateLimiter {
	return &rateLimiter{
		buckets: make(map[string]*bucketEntry, maxClients),
		heap:    make(bucketHeap, 0, maxClients),
	}
}

// allow samples time after taking the mutex, preventing goroutines from
// applying timestamps out of order and accidentally crediting quota twice.
func (l *rateLimiter) allow(identity string) (allowed bool, retry time.Duration, stateFull bool) {
	l.mu.Lock()
	defer l.mu.Unlock()

	now := time.Now()
	b := l.buckets[identity]

	if b == nil {
		if len(l.buckets) >= maxClients {
			for len(l.heap) > 0 && !l.heap[0].fullAt.After(now) {
				candidate := l.heap[0]
				needed := refillDuration(candidate.tokens)

				if now.Sub(candidate.last) < needed {
					candidate.fullAt = candidate.last.Add(needed)
					heap.Fix(&l.heap, candidate.index)
					break
				}

				heap.Pop(&l.heap)
				delete(l.buckets, candidate.identity)
				break
			}

			if len(l.buckets) >= maxClients {
				return false, 0, true
			}
		}

		b = &bucketEntry{
			identity: identity,
			tokens:   5.0,
			last:     now,
			index:    -1,
		}
		refreshFullAt(b)
		l.buckets[identity] = b
		heap.Push(&l.heap, b)
	}

	elapsed := now.Sub(b.last).Seconds()
	if elapsed > 0 {
		b.tokens = math.Min(5.0, b.tokens+elapsed*0.5)
		b.last = now
	}

	if b.tokens < 1.0 {
		waitSeconds := (1.0 - b.tokens) / 0.5
		if waitSeconds < 0 {
			waitSeconds = 0
		}

		refreshFullAt(b)
		heap.Fix(&l.heap, b.index)
		return false, time.Duration(math.Ceil(waitSeconds * float64(time.Second))), false
	}

	b.tokens--
	refreshFullAt(b)
	heap.Fix(&l.heap, b.index)
	return true, 0, false
}

type gateway struct {
	search          *origin
	files           *origin
	resolve         *origin
	client          *http.Client
	logs            *logManager
	limiter         *rateLimiter
	active          chan struct{}
	responseBuffers chan struct{}
	stopping        atomic.Bool
	rootCtx         context.Context
	cancelWork      context.CancelFunc
}

type trackedWriter struct {
	http.ResponseWriter
	status int
	wrote  bool
}

func (w *trackedWriter) WriteHeader(code int) {
	if w.wrote {
		return
	}
	w.status = code
	w.wrote = true
	w.ResponseWriter.WriteHeader(code)
}

func (w *trackedWriter) Write(p []byte) (int, error) {
	if !w.wrote {
		w.WriteHeader(http.StatusOK)
	}
	return w.ResponseWriter.Write(p)
}

func (w *trackedWriter) statusCode() int {
	if !w.wrote {
		return http.StatusOK
	}
	return w.status
}

func rawPathAndQuery(target string) (path, query string, hasQuery bool) {
	i := strings.IndexByte(target, '?')
	if i < 0 {
		return target, "", false
	}
	return target[:i], target[i+1:], true
}

type routeKind int

const (
	routeUnknown routeKind = iota
	routeSearch
	routeFiles
	routeResolve
	routeHealth
	routeMetrics
)

func classifyRoute(rawPath string) routeKind {
	switch {
	case rawPath == "/v1/search":
		return routeSearch

	case strings.HasPrefix(rawPath, "/v1/files/") &&
		!strings.Contains(strings.TrimPrefix(rawPath, "/v1/files/"), "/"):
		return routeFiles

	case rawPath == "/v1/tools/resolve":
		return routeResolve

	case rawPath == "/healthz":
		return routeHealth

	case rawPath == "/_internal/metrics":
		return routeMetrics

	default:
		return routeUnknown
	}
}

func routeTemplate(rawPath string) string {
	switch classifyRoute(rawPath) {
	case routeSearch:
		return "/v1/search"
	case routeFiles:
		return "/v1/files/{file_id}"
	case routeResolve:
		return "/v1/tools/resolve"
	case routeHealth:
		return "/healthz"
	case routeMetrics:
		return "/_internal/metrics"
	default:
		return "unmatched"
	}
}

func validIdentity(values []string) (string, bool) {
	if len(values) != 1 {
		return "", false
	}

	s := values[0]
	if len(s) < 1 || len(s) > 128 {
		return "", false
	}

	for i := 0; i < len(s); i++ {
		c := s[i]
		if !((c >= 'a' && c <= 'z') ||
			(c >= 'A' && c <= 'Z') ||
			(c >= '0' && c <= '9') ||
			c == '_' || c == '-') {
			return "", false
		}
	}

	return s, true
}

func safeMethod(method string) string {
	if method == "" || len(method) > 32 {
		return "OTHER"
	}

	for i := 0; i < len(method); i++ {
		c := method[i]
		if !((c >= 'a' && c <= 'z') ||
			(c >= 'A' && c <= 'Z') ||
			(c >= '0' && c <= '9') ||
			strings.ContainsRune("!#$%&'*+-.^_`|~", rune(c))) {
			return "OTHER"
		}
	}

	return method
}

func requestTargetTooLarge(r *http.Request, meta headerMeta, haveMeta bool) bool {
	if haveMeta && meta.valid {
		return meta.targetBytes > maxTargetBytes
	}
	return len(r.RequestURI) > maxTargetBytes
}

func headerLimitExceeded(r *http.Request, meta headerMeta, haveMeta bool) bool {
	if haveMeta && meta.valid {
		return meta.fields > 64 || meta.headerBytes > maxHeaderBytes
	}

	// Fallback for direct handler use without the raw-connection accounting.
	count, bytesSeen := 0, 0
	seenTE := false

	for name, values := range r.Header {
		if strings.EqualFold(name, "Transfer-Encoding") {
			seenTE = true
		}
		for _, value := range values {
			count++
			bytesSeen += len(name) + 2 + len(value) + 2
		}
	}

	if r.Host != "" {
		count++
		bytesSeen += len("Host") + 2 + len(r.Host) + 2
	}

	if len(r.TransferEncoding) > 0 && !seenTE {
		for _, value := range r.TransferEncoding {
			count++
			bytesSeen += len("Transfer-Encoding") + 2 + len(value) + 2
		}
	}

	return count > 64 || bytesSeen > maxHeaderBytes
}

func readBodyLimited(w http.ResponseWriter, r *http.Request) ([]byte, error) {
	defer r.Body.Close()

	lr := http.MaxBytesReader(w, r.Body, maxRequestBody)
	b, err := io.ReadAll(lr)
	if err != nil {
		return b, err
	}

	if len(b) > maxRequestBody {
		return b, &http.MaxBytesError{Limit: maxRequestBody}
	}

	return b, nil
}

func validateSearch(rawQuery string, hasQuery bool) (string, bool) {
	if !hasQuery || rawQuery == "" || strings.Contains(rawQuery, "&") {
		return "", false
	}

	values, err := url.ParseQuery(rawQuery)
	if err != nil || len(values) != 1 {
		return "", false
	}

	v, ok := values["q"]
	if !ok || len(v) != 1 || len(v[0]) < 1 || len(v[0]) > 64 {
		return "", false
	}

	for i := 0; i < len(v[0]); i++ {
		c := v[0][i]
		if !((c >= 'a' && c <= 'z') ||
			(c >= 'A' && c <= 'Z') ||
			(c >= '0' && c <= '9') ||
			c == ' ' || c == '_' || c == '-') {
			return "", false
		}
	}

	return v[0], true
}

func validateFileID(rawPath string) (string, bool) {
	const prefix = "/v1/files/"
	if !strings.HasPrefix(rawPath, prefix) {
		return "", false
	}

	rawID := strings.TrimPrefix(rawPath, prefix)
	if rawID == "" || strings.Contains(rawID, "/") {
		return "", false
	}

	id, err := url.PathUnescape(rawID)
	if err != nil || len(id) < 1 || len(id) > 64 {
		return "", false
	}

	for i := 0; i < len(id); i++ {
		c := id[i]
		if !((c >= 'a' && c <= 'z') ||
			(c >= 'A' && c <= 'Z') ||
			(c >= '0' && c <= '9') ||
			c == '_' || c == '-') {
			return "", false
		}
	}

	return id, true
}

func validHostname(host string) bool {
	if len(host) < 1 || len(host) > 253 {
		return false
	}

	for i := 0; i < len(host); i++ {
		if host[i] >= 0x80 {
			return false
		}
	}

	if strings.HasSuffix(host, ".") {
		return false
	}

	for _, label := range strings.Split(host, ".") {
		if len(label) < 1 || len(label) > 63 ||
			label[0] == '-' || label[len(label)-1] == '-' {
			return false
		}

		for i := 0; i < len(label); i++ {
			c := label[i]
			if !((c >= 'a' && c <= 'z') ||
				(c >= 'A' && c <= 'Z') ||
				(c >= '0' && c <= '9') || c == '-') {
				return false
			}
		}
	}

	return true
}

func validateResolve(contentTypes []string, body []byte) (string, bool) {
	if len(contentTypes) != 1 {
		return "", false
	}

	mediaType, params, err := mime.ParseMediaType(contentTypes[0])
	if err != nil ||
		!strings.EqualFold(mediaType, "application/json") ||
		len(params) > 1 {
		return "", false
	}

	if len(params) == 1 {
		charset, ok := params["charset"]
		if !ok || !strings.EqualFold(charset, "utf-8") {
			return "", false
		}
	}

	if !utf8.Valid(body) {
		return "", false
	}

	dec := json.NewDecoder(bytes.NewReader(body))
	first, err := dec.Token()
	if err != nil || first != json.Delim('{') {
		return "", false
	}

	seenHost := false
	host := ""

	for dec.More() {
		tok, e := dec.Token()
		if e != nil {
			return "", false
		}

		key, ok := tok.(string)
		if !ok || key != "host" || seenHost {
			return "", false
		}
		seenHost = true

		var raw json.RawMessage
		if e := dec.Decode(&raw); e != nil {
			return "", false
		}
		if e := json.Unmarshal(raw, &host); e != nil {
			return "", false
		}
	}

	last, err := dec.Token()
	if err != nil || last != json.Delim('}') || !seenHost {
		return "", false
	}

	var trailing json.RawMessage
	if err := dec.Decode(&trailing); err != io.EOF {
		return "", false
	}

	if !validHostname(host) {
		return "", false
	}

	return strings.ToLower(host), true
}

var hopHeaders = map[string]struct{}{
	"connection":          {},
	"proxy-connection":    {},
	"keep-alive":          {},
	"proxy-authenticate":  {},
	"proxy-authorization": {},
	"te":                  {},
	"trailer":             {},
	"transfer-encoding":   {},
	"upgrade":             {},
}

func connectionNominations(h http.Header) map[string]struct{} {
	out := make(map[string]struct{})

	for _, headerName := range []string{"Connection", "Proxy-Connection"} {
		for _, value := range h.Values(headerName) {
			for _, part := range strings.Split(value, ",") {
				name := strings.ToLower(strings.TrimSpace(part))
				if name != "" {
					out[name] = struct{}{}
				}
			}
		}
	}

	return out
}

func nominatedRequiredHeader(h http.Header) bool {
	nominated := connectionNominations(h)

	for _, name := range []string{"Accept", "Content-Type", "If-None-Match"} {
		if _, ok := nominated[strings.ToLower(name)]; ok {
			return true
		}
	}

	return false
}

func forwardedRequestHeaders(dst, src http.Header) {
	nominated := connectionNominations(src)

	for _, name := range []string{"Accept", "Content-Type", "If-None-Match"} {
		lower := strings.ToLower(name)

		if _, hop := hopHeaders[lower]; hop {
			continue
		}
		if _, nom := nominated[lower]; nom {
			continue
		}

		for _, value := range src.Values(name) {
			dst.Add(name, value)
		}
	}

	// Suppress net/http's implicit User-Agent.
	dst["User-Agent"] = []string{}
}

func forwardedResponseHeaders(dst, src http.Header) {
	nominated := connectionNominations(src)

	for name, values := range src {
		lower := strings.ToLower(name)

		if _, hop := hopHeaders[lower]; hop {
			continue
		}
		if _, nom := nominated[lower]; nom {
			continue
		}

		for _, value := range values {
			dst.Add(name, value)
		}
	}
}

func requestTooLarge(w http.ResponseWriter, r *http.Request) {
	r.Close = true
	w.Header().Set("Connection", "close")
	httpError(w, http.StatusRequestEntityTooLarge)
}

func methodNotAllowed(w http.ResponseWriter, allow string) {
	w.Header().Set("Allow", allow)
	httpError(w, http.StatusMethodNotAllowed)
}

func httpError(w http.ResponseWriter, status int) {
	msg := http.StatusText(status)
	if msg == "" {
		msg = "Request Failed"
	}
	http.Error(w, msg, status)
}

func (g *gateway) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	meta, haveMeta := rawHeaderMeta(r)
	rawPath, rawQuery, hasQuery := rawPathAndQuery(r.RequestURI)
	kind := classifyRoute(rawPath)

	if g.stopping.Load() {
		httpError(w, http.StatusServiceUnavailable)
		return
	}

	if kind == routeHealth || kind == routeMetrics {
		g.serveSpecial(w, r, kind, meta, haveMeta)
		return
	}

	if !g.logs.reserve() {
		httpError(w, http.StatusServiceUnavailable)
		return
	}

	tw := &trackedWriter{ResponseWriter: w}
	started := time.Now()

	identityRaw, identityOK := validIdentity(r.Header.Values("X-Verified-Client-ID"))
	clientID := "unverified"
	if identityOK {
		clientID = g.logs.pseudonym(identityRaw)
	}

	ev := logEvent{
		RequestID: g.logs.nextRequestID(),
		EventID:   g.logs.nextEventID(),
		Timestamp: started.UTC().Format(time.RFC3339Nano),
		Method:    safeMethod(r.Method),
		Route:     routeTemplate(rawPath),
		ClientID:  clientID,
	}

	reason, outcome := "internal_error", "error"

	defer func() {
		if recover() != nil {
			if !tw.wrote {
				httpError(tw, http.StatusInternalServerError)
			}
			reason, outcome = "internal_error", "error"
		}

		ev.Status = tw.statusCode()
		if !tw.wrote && (r.Context().Err() != nil || g.rootCtx.Err() != nil) {
			ev.Status = 499
		}
		ev.Duration = time.Since(started).Milliseconds()
		ev.Reason = reason
		ev.Outcome = outcome

		g.logs.emit(ev)
	}()

	select {
	case g.active <- struct{}{}:
		defer func() { <-g.active }()
	default:
		reason, outcome = "concurrency_limit", "rejected"
		httpError(tw, http.StatusServiceUnavailable)
		return
	}

	if g.stopping.Load() {
		reason, outcome = "shutting_down", "rejected"
		httpError(tw, http.StatusServiceUnavailable)
		return
	}

	if r.ProtoMajor != 1 || r.ProtoMinor != 1 {
		reason, outcome = "unsupported_protocol", "rejected"
		httpError(tw, http.StatusBadRequest)
		return
	}

	if requestTargetTooLarge(r, meta, haveMeta) ||
		headerLimitExceeded(r, meta, haveMeta) {
		reason, outcome = "request_headers_or_target_too_large", "rejected"
		requestTooLarge(tw, r)
		return
	}

	if !identityOK {
		reason, outcome = "untrusted_identity", "rejected"
		httpError(tw, http.StatusUnauthorized)
		return
	}

	if kind == routeUnknown {
		reason, outcome = "not_found", "rejected"
		httpError(tw, http.StatusNotFound)
		return
	}

	var expectedMethod string
	switch kind {
	case routeSearch, routeFiles:
		expectedMethod = http.MethodGet
	case routeResolve:
		expectedMethod = http.MethodPost
	}

	if r.Method != expectedMethod {
		reason, outcome = "method_not_allowed", "rejected"
		methodNotAllowed(tw, expectedMethod)
		return
	}

	if r.ContentLength > maxRequestBody {
		reason, outcome = "body_too_large", "rejected"
		requestTooLarge(tw, r)
		return
	}

	if nominatedRequiredHeader(r.Header) {
		reason, outcome = "conflicting_connection_header", "rejected"
		httpError(tw, http.StatusBadRequest)
		return
	}

	body, bodyErr := readBodyLimited(tw, r)
	if bodyErr != nil {
		var maxErr *http.MaxBytesError

		if errors.As(bodyErr, &maxErr) {
			reason, outcome = "body_too_large", "rejected"
			requestTooLarge(tw, r)
			return
		}

		if g.rootCtx.Err() != nil {
			reason, outcome = "shutting_down", "error"
			httpError(tw, http.StatusServiceUnavailable)
			return
		}

		if r.Context().Err() != nil {
			reason, outcome = "client_cancelled", "error"
			tw.WriteHeader(499)
			return
		}

		reason, outcome = "invalid_request_body", "rejected"
		httpError(tw, http.StatusBadRequest)
		return
	}

	var (
		upstream      *origin
		upstreamPath  string
		upstreamQuery string
		method        string
		canonicalBody []byte
	)

	switch kind {
	case routeSearch:
		term, ok := validateSearch(rawQuery, hasQuery)
		if !ok {
			reason, outcome = "invalid_search_query", "rejected"
			httpError(tw, http.StatusBadRequest)
			return
		}

		upstream = g.search
		upstreamPath = "/v1/search"
		method = http.MethodGet
		upstreamQuery = url.Values{"q": []string{term}}.Encode()

	case routeFiles:
		fileID, ok := validateFileID(rawPath)
		if !ok || hasQuery {
			reason, outcome = "invalid_file_id_or_query", "rejected"
			httpError(tw, http.StatusBadRequest)
			return
		}

		upstream = g.files
		upstreamPath = "/v1/files/" + fileID
		method = http.MethodGet
		upstreamQuery = ""

	case routeResolve:
		if hasQuery {
			reason, outcome = "invalid_resolve_query", "rejected"
			httpError(tw, http.StatusBadRequest)
			return
		}

		host, ok := validateResolve(r.Header.Values("Content-Type"), body)
		if !ok {
			reason, outcome = "invalid_resolve_json", "rejected"
			httpError(tw, http.StatusBadRequest)
			return
		}

		canonicalBody, _ = json.Marshal(struct {
			Host string `json:"host"`
		}{Host: host})

		upstream = g.resolve
		upstreamPath = "/v1/tools/resolve"
		method = http.MethodPost
		upstreamQuery = ""

	default:
		reason, outcome = "not_found", "rejected"
		httpError(tw, http.StatusNotFound)
		return
	}

	// Reserve the aggregate response-buffer budget before consuming quota
	// or contacting an upstream backend.
	select {
	case g.responseBuffers <- struct{}{}:
		defer func() { <-g.responseBuffers }()
	default:
		reason, outcome = "response_memory_budget", "rejected"
		httpError(tw, http.StatusServiceUnavailable)
		return
	}

	allowed, retry, full := g.limiter.allow(identityRaw)
	if full {
		reason, outcome = "rate_state_full", "rejected"
		httpError(tw, http.StatusServiceUnavailable)
		return
	}

	if !allowed {
		reason, outcome = "quota_exhausted", "rejected"
		seconds := int(math.Ceil(retry.Seconds()))
		if seconds < 1 {
			seconds = 1
		}
		tw.Header().Set("Retry-After", strconv.Itoa(seconds))
		httpError(tw, http.StatusTooManyRequests)
		return
	}

	var bodyReader io.Reader
	if method == http.MethodPost {
		bodyReader = bytes.NewReader(canonicalBody)
	}

	target := upstream.target(upstreamPath, upstreamQuery)
	upReq, err := http.NewRequestWithContext(
		r.Context(), method, target.String(), bodyReader,
	)
	if err != nil {
		reason, outcome = "upstream_request_failed", "error"
		httpError(tw, http.StatusBadGateway)
		return
	}

	forwardedRequestHeaders(upReq.Header, r.Header)

	if method == http.MethodPost {
		// The validated body is canonical JSON, independently of client headers.
		upReq.Header.Set("Content-Type", "application/json")
	}

	resp, err := g.client.Do(upReq)
	if err != nil {
		if g.rootCtx.Err() != nil {
			reason, outcome = "shutting_down", "error"
			httpError(tw, http.StatusServiceUnavailable)
			return
		}

		if r.Context().Err() != nil {
			reason, outcome = "client_cancelled", "error"
			tw.WriteHeader(499)
			return
		}

		if isTimeout(err) {
			reason, outcome = "upstream_timeout", "error"
			httpError(tw, http.StatusGatewayTimeout)
			return
		}

		reason, outcome = "upstream_failure", "error"
		httpError(tw, http.StatusBadGateway)
		return
	}
	defer resp.Body.Close()

	if resp.StatusCode < 200 ||
		resp.StatusCode == http.StatusSwitchingProtocols {
		reason, outcome = "unsupported_upstream_status", "error"
		httpError(tw, http.StatusBadGateway)
		return
	}

	responseBody, readErr, tooLarge := readResponseBounded(resp)
	if tooLarge {
		reason, outcome = "upstream_response_too_large", "error"
		httpError(tw, http.StatusBadGateway)
		return
	}

	if readErr != nil {
		if g.rootCtx.Err() != nil {
			reason, outcome = "shutting_down", "error"
			httpError(tw, http.StatusServiceUnavailable)
			return
		}

		if r.Context().Err() != nil {
			reason, outcome = "client_cancelled", "error"
			tw.WriteHeader(499)
			return
		}

		if isTimeout(readErr) {
			reason, outcome = "upstream_timeout", "error"
			httpError(tw, http.StatusGatewayTimeout)
			return
		}

		reason, outcome = "upstream_failure", "error"
		httpError(tw, http.StatusBadGateway)
		return
	}

	forwardedResponseHeaders(tw.Header(), resp.Header)

	nominatedResponseHeaders := connectionNominations(resp.Header)
	_, contentLengthNominated := nominatedResponseHeaders["content-length"]

	if resp.ContentLength >= 0 &&
		int64(len(responseBody)) == resp.ContentLength &&
		resp.StatusCode != http.StatusNoContent &&
		resp.StatusCode != http.StatusNotModified &&
		!contentLengthNominated {
		tw.Header().Set("Content-Length", strconv.Itoa(len(responseBody)))
	}

	tw.WriteHeader(resp.StatusCode)

	if len(responseBody) > 0 {
		if _, err := tw.Write(responseBody); err != nil {
			reason, outcome = "client_write_failed", "error"
			return
		}
	}

	reason, outcome = "upstream_response", "proxied"
}

func readResponseBounded(resp *http.Response) ([]byte, error, bool) {
	if resp.StatusCode == http.StatusNoContent ||
		resp.StatusCode == http.StatusNotModified {
		return []byte{}, nil, false
	}

	if resp.ContentLength > maxResponseBody {
		return nil, nil, true
	}

	if resp.ContentLength >= 0 {
		n := int(resp.ContentLength)
		buf := make([]byte, n)

		if n == 0 {
			return buf, nil, false
		}

		got, err := io.ReadFull(resp.Body, buf)
		if err != nil {
			return nil, err, false
		}
		if got != n {
			return nil, io.ErrUnexpectedEOF, false
		}

		return buf, nil, false
	}

	// Unknown-length responses use a fixed-size allocation. At most
	// maxResponseBuffers such buffers can exist concurrently.
	buf := make([]byte, maxResponseBody+1)
	n, err := io.ReadFull(resp.Body, buf)

	if n > maxResponseBody {
		return nil, nil, true
	}
	if err == nil {
		return nil, nil, true
	}
	if err == io.EOF || err == io.ErrUnexpectedEOF {
		return buf[:n], nil, false
	}

	return nil, err, false
}

func (g *gateway) serveSpecial(
	w http.ResponseWriter,
	r *http.Request,
	kind routeKind,
	meta headerMeta,
	haveMeta bool,
) {
	select {
	case g.active <- struct{}{}:
		defer func() { <-g.active }()
	default:
		httpError(w, http.StatusServiceUnavailable)
		return
	}

	if !validIdentityOnly(r) {
		httpError(w, http.StatusUnauthorized)
		return
	}

	if !g.logsHealthy() {
		httpError(w, http.StatusServiceUnavailable)
		return
	}

	if g.stopping.Load() {
		httpError(w, http.StatusServiceUnavailable)
		return
	}

	if r.ProtoMajor != 1 || r.ProtoMinor != 1 {
		httpError(w, http.StatusBadRequest)
		return
	}

	if requestTargetTooLarge(r, meta, haveMeta) ||
		headerLimitExceeded(r, meta, haveMeta) {
		requestTooLarge(w, r)
		return
	}

	if r.Method != http.MethodGet {
		methodNotAllowed(w, "GET")
		return
	}

	if r.ContentLength > maxRequestBody {
		requestTooLarge(w, r)
		return
	}

	if _, err := readBodyLimited(w, r); err != nil {
		var maxErr *http.MaxBytesError
		if errors.As(err, &maxErr) {
			requestTooLarge(w, r)
		} else {
			httpError(w, http.StatusBadRequest)
		}
		return
	}

	if kind == routeHealth {
		w.Header().Set("Content-Type", "text/plain; charset=utf-8")
		w.Header().Set("Cache-Control", "no-store")
		w.WriteHeader(http.StatusOK)
		_, _ = io.WriteString(w, "ok\n")
		return
	}

	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.Header().Set("Cache-Control", "no-store")
	_ = json.NewEncoder(w).Encode(g.logs.metrics())
}

func validIdentityOnly(r *http.Request) bool {
	_, ok := validIdentity(r.Header.Values("X-Verified-Client-ID"))
	return ok
}

func (g *gateway) logsHealthy() bool {
	g.logs.admitMu.Lock()
	defer g.logs.admitMu.Unlock()
	return !g.logs.unhealthy
}

func isTimeout(err error) bool {
	if errors.Is(err, context.DeadlineExceeded) {
		return true
	}

	var ne net.Error
	return errors.As(err, &ne) && ne.Timeout()
}

func newHTTPClient() *http.Client {
	transport := &http.Transport{
		Proxy:                  nil,
		DialContext:            (&net.Dialer{Timeout: 2 * time.Second, KeepAlive: 30 * time.Second}).DialContext,
		ForceAttemptHTTP2:      false,
		MaxIdleConns:           128,
		MaxIdleConnsPerHost:    64,
		MaxConnsPerHost:        maxResponseBuffers,
		MaxResponseHeaderBytes: 16 << 10,
		IdleConnTimeout:        30 * time.Second,
		ResponseHeaderTimeout:  2 * time.Second,
		DisableCompression:     true,
	}

	return &http.Client{
		Transport: transport,
		Timeout:   2 * time.Second,
		CheckRedirect: func(_ *http.Request, _ []*http.Request) error {
			return http.ErrUseLastResponse
		},
	}
}

func run() int {
	signal.Ignore(syscall.SIGPIPE)

	replica := os.Getenv("REPLICA_ID")
	if replica != "0" && replica != "1" &&
		replica != "2" && replica != "3" {
		fmt.Fprintln(os.Stderr, "gateway: REPLICA_ID must be 0, 1, 2, or 3")
		return 2
	}

	search, err := parseOrigin(os.Getenv("SEARCH_BACKEND_URL"))
	if err != nil {
		fmt.Fprintln(os.Stderr, "gateway: invalid SEARCH_BACKEND_URL")
		return 2
	}

	files, err := parseOrigin(os.Getenv("FILES_BACKEND_URL"))
	if err != nil {
		fmt.Fprintln(os.Stderr, "gateway: invalid FILES_BACKEND_URL")
		return 2
	}

	resolve, err := parseOrigin(os.Getenv("RESOLVE_BACKEND_URL"))
	if err != nil {
		fmt.Fprintln(os.Stderr, "gateway: invalid RESOLVE_BACKEND_URL")
		return 2
	}

	addr := os.Getenv("GATEWAY_ADDR")
	if addr == "" {
		addr = "127.0.0.1:8080"
	}

	logs, err := newLogManager()
	if err != nil {
		fmt.Fprintln(os.Stderr, "gateway: unable to initialize logging")
		return 2
	}

	rootCtx, cancelWork := context.WithCancel(context.Background())

	g := &gateway{
		search:          search,
		files:           files,
		resolve:         resolve,
		client:          newHTTPClient(),
		logs:            logs,
		limiter:         newRateLimiter(),
		active:          make(chan struct{}, maxConcurrent),
		responseBuffers: make(chan struct{}, maxResponseBuffers),
		rootCtx:         rootCtx,
		cancelWork:      cancelWork,
	}

	server := &http.Server{
		Addr:              addr,
		Handler:           g,
		ReadHeaderTimeout: 5 * time.Second,
		ReadTimeout:       10 * time.Second,
		WriteTimeout:      3 * time.Second,
		IdleTimeout:       30 * time.Second,
		MaxHeaderBytes:    parserHeaderBytes,
		ErrorLog:          log.New(io.Discard, "", 0),
		BaseContext:       func(net.Listener) context.Context { return rootCtx },
		ConnContext: func(ctx context.Context, c net.Conn) context.Context {
			if ac, ok := c.(*accountingConn); ok {
				return context.WithValue(ctx, connContextKey{}, ac)
			}
			return ctx
		},
	}

	listener, err := net.Listen("tcp", addr)
	if err != nil {
		fmt.Fprintln(os.Stderr, "gateway: unable to listen")
		return 2
	}

	serveErr := make(chan error, 1)
	go func() {
		serveErr <- server.Serve(accountingListener{Listener: listener})
	}()

	signals := make(chan os.Signal, 1)
	signal.Notify(signals, syscall.SIGTERM, os.Interrupt)
	defer signal.Stop(signals)

	select {
	case <-signals:
		signalAt := time.Now()

		g.stopping.Store(true)
		server.SetKeepAlivesEnabled(false)

		shutdownCtx, cancel := context.WithDeadline(
			context.Background(),
			signalAt.Add(2500*time.Millisecond),
		)
		_ = server.Shutdown(shutdownCtx)
		cancel()

		// Cancel any work still running at the signal-anchored work deadline.
		g.cancelWork()
		_ = server.Close()

		drainDeadline := signalAt.Add(2850 * time.Millisecond)
		for time.Now().Before(drainDeadline) {
			if logs.drained() {
				os.Exit(0)
			}
			time.Sleep(2 * time.Millisecond)
		}

		// A permanently blocked stdout write cannot be interrupted portably.
		// Events remaining at this deadline may be lost; draining is best effort.
		os.Exit(0)
		return 0

	case err := <-serveErr:
		if err != nil && !errors.Is(err, http.ErrServerClosed) {
			fmt.Fprintln(os.Stderr, "gateway: server stopped unexpectedly")
			cancelWork()
			return 2
		}

		cancelWork()
		return 0
	}
}

func main() {
	os.Exit(run())
}
